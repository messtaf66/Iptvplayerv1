package com.tvmax.player.ui

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import com.tvmax.player.R

class HomeActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b); setContentView(build())}
 private fun build():View { val root=LinearLayout(this); root.orientation=LinearLayout.VERTICAL; root.setPadding(48,22,48,22); root.setBackgroundColor(Color.rgb(9,11,34))
  val title=TextView(this); title.text="TvMax"; title.textSize=38f; title.setTextColor(Color.WHITE); title.gravity=Gravity.CENTER; root.addView(title,LinearLayout.LayoutParams(-1,62))
  val info=TextView(this); info.text="Votre lecteur IPTV"; info.textSize=18f; info.setTextColor(Color.LTGRAY); info.gravity=Gravity.CENTER; root.addView(info,LinearLayout.LayoutParams(-1,45))
  val grid=GridLayout(this); grid.columnCount=3; grid.rowCount=3; root.addView(grid,LinearLayout.LayoutParams(-1,0,1f))
  add(grid,"📺  EN DIRECT"){open("live")}; add(grid,"🎬  FILMS"){open("movies")}; add(grid,"📚  SÉRIES"){open("series")}
  add(grid,"🔎  RECHERCHE"){open("search")}; add(grid,"➕  AJOUTER PLAYLIST"){startActivity(Intent(this,PlaylistActivity::class.java))}; add(grid,"⚙  PARAMÈTRES"){startActivity(Intent(this,SettingsActivity::class.java))}
  add(grid,"↻  RECHARGER"){open("reload")}; add(grid,"🔄  CHANGER PLAYLIST"){startActivity(Intent(this,PlaylistActivity::class.java))}; add(grid,"⏻  QUITTER"){finishAffinity()}
  return root }
 private fun add(g:GridLayout,t:String,click:()->Unit){val v=Button(this);v.text=t;v.textSize=18f;v.isFocusable=true;v.background=getDrawable(R.drawable.focus_bg);v.setTextColor(Color.WHITE);v.setOnClickListener{click()}; val p=GridLayout.LayoutParams();p.width=0;p.height=115;p.columnSpec=GridLayout.spec(GridLayout.UNDEFINED,1f);p.setMargins(10,8,10,8);g.addView(v,p)}
 private fun open(kind:String){startActivity(Intent(this,CatalogActivity::class.java).putExtra("kind",kind))}
}
