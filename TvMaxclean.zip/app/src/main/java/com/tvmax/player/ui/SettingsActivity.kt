package com.tvmax.player.ui
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
class SettingsActivity:Activity(){override fun onCreate(b:Bundle?){super.onCreate(b);val l=LinearLayout(this);l.orientation=LinearLayout.VERTICAL;l.setPadding(50,30,50,30);l.setBackgroundColor(Color.rgb(9,11,34));val h=TextView(this);h.text="Paramètres";h.textSize=34f;h.setTextColor(Color.WHITE);h.gravity=Gravity.CENTER;l.addView(h,LinearLayout.LayoutParams(-1,80));listOf("Ajouter une playlist","Changer la playlist","Contrôle parental","Langue","Disposition","Masquer les catégories","Effacer l’historique","Format de l'heure","Sous-titres","Lecteur externe").forEach{v->val x=Button(this);x.text=v;x.textSize=18f;x.isFocusable=true;x.setTextColor(Color.WHITE);x.background=getDrawable(com.tvmax.player.R.drawable.focus_bg);l.addView(x,LinearLayout.LayoutParams(-1,64).apply{setMargins(0,5,0,5)})};setContentView(l)}}
