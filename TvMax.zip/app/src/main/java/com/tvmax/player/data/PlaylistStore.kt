package com.tvmax.player.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class SavedPlaylist(
    val name: String,
    val type: String,
    val host: String = "",
    val username: String = "",
    val password: String = "",
    val url: String = ""
)

object PlaylistStore {
    private const val PREFS = "tvmax_playlists"
    private const val KEY = "items"

    fun get(context: Context): List<SavedPlaylist> {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "[]") ?: "[]"
        val a = JSONArray(raw)
        return (0 until a.length()).map { i ->
            val o = a.getJSONObject(i)
            SavedPlaylist(
                name = o.optString("name"), type = o.optString("type"),
                host = o.optString("host"), username = o.optString("username"),
                password = o.optString("password"), url = o.optString("url")
            )
        }
    }

    fun add(context: Context, item: SavedPlaylist) {
        val current = get(context).toMutableList()
        current.removeAll { it.name.equals(item.name, ignoreCase = true) }
        current.add(0, item)
        save(context, current)
    }

    fun remove(context: Context, name: String) {
        save(context, get(context).filterNot { it.name == name })
    }

    fun save(context: Context, items: List<SavedPlaylist>) {
        val a = JSONArray()
        items.forEach { p ->
            a.put(JSONObject().apply {
                put("name", p.name); put("type", p.type); put("host", p.host)
                put("username", p.username); put("password", p.password); put("url", p.url)
            })
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, a.toString()).apply()
    }

    fun select(context: Context, item: SavedPlaylist) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString("selected", item.name).apply()
    }

    fun selected(context: Context): SavedPlaylist? {
        val name = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("selected", null) ?: return null
        return get(context).firstOrNull { it.name == name }
    }
}
