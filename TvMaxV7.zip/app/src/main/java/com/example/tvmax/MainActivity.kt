package com.example.tvmax

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL

private const val BG_TOP = 0xFF151B72.toInt()
private const val BG_MID = 0xFF3120A8.toInt()
private const val BG_BOTTOM = 0xFF150A3A.toInt()
private const val CARD = 0xFFE21C86.toInt()
private const val CARD_DARK = 0xFFB90F75.toInt()
private const val WHITE = 0xFFFFFFFF.toInt()
private const val SOFT = 0xFFE9E7FF.toInt()
private const val DIM = 0xFFC8C4E7.toInt()
private const val FOCUS = 0xFFFFF5A6.toInt()
private const val SHADOW = 0x33100035.toInt()

data class TvItem(
    val id: String,
    val name: String,
    val logo: String,
    val type: String,
    val extension: String = "",
    val categoryId: String = ""
)

data class SettingItem(val icon: String, val label: String, val action: () -> Unit)

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var body: LinearLayout
    private var server = ""
    private var username = ""
    private var password = ""
    private var allItems = mutableListOf<TvItem>()
    private var favorites = mutableSetOf<String>()
    private var history = mutableListOf<String>()
    private var player: ExoPlayer? = null
    private var playlistName = "Ma playlist"

    private val prefs by lazy { getSharedPreferences("tvmax7", Context.MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        server = prefs.getString("server", "") ?: ""
        username = prefs.getString("user", "") ?: ""
        password = prefs.getString("pass", "") ?: ""
        playlistName = prefs.getString("playlist", "Ma playlist") ?: "Ma playlist"
        favorites = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        history = (prefs.getStringSet("history", emptySet()) ?: emptySet()).toMutableList()
        if (server.isBlank()) showLogin() else showHome()
    }

    private fun showLogin() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(80), dp(30), dp(80), dp(30))
            background = tvGradient()
        }
        page.addView(text("TVMAX", 46, WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(70)))
        page.addView(text("Votre télévision. Votre interface.", 18, SOFT, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(45)))
        val panel = rounded(0xAA160E58.toInt(), 28f)
        panel.orientation = LinearLayout.VERTICAL
        panel.gravity = Gravity.CENTER
        panel.setPadding(dp(35), dp(28), dp(35), dp(28))
        val s = input("URL du serveur", server)
        val u = input("Nom d'utilisateur", username)
        val p = input("Mot de passe", password)
        p.inputType = 0x81
        panel.addView(s, lp(-1, dp(58))); panel.addView(space(dp(10)), lp(-1, dp(10)))
        panel.addView(u, lp(-1, dp(58))); panel.addView(space(dp(10)), lp(-1, dp(10)))
        panel.addView(p, lp(-1, dp(58))); panel.addView(space(dp(16)), lp(-1, dp(16)))
        val connect = tvButton("SE CONNECTER") {
            server = s.text.toString().trim().removeSuffix("/")
            username = u.text.toString().trim(); password = p.text.toString().trim()
            connect()
        }
        panel.addView(connect, lp(-1, dp(60)))
        page.addView(panel, lp(dp(620), dp(350)))
        page.addView(text("Utilisez uniquement des services et contenus auxquels vous êtes autorisé à accéder.", 13, DIM, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(45)))
        setContentView(page)
        connect.requestFocus()
    }

    private fun connect() {
        lifecycleScope.launch {
            try {
                val raw = withContext(Dispatchers.IO) {
                    URL("$server/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}").readText()
                }
                if (!JSONObject(raw).has("user_info")) error("Identifiants incorrects")
                prefs.edit().putString("server", server).putString("user", username).putString("pass", password).apply()
                showHome()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Connexion impossible : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun basePage(title: String, back: Boolean = false): LinearLayout {
        root = FrameLayout(this)
        root.background = tvGradient()
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(42), dp(24), dp(42), dp(22))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        if (back) {
            val b = smallButton("‹") { showHome() }
            header.addView(b, lp(dp(65), dp(55)))
            header.addView(space(dp(18)), lp(dp(18), dp(1)))
        }
        header.addView(text(title, 27, WHITE, true).apply { gravity = Gravity.CENTER }, lp(0, dp(58), 1f))
        header.addView(text("TVMAX  •  V7.0", 13, SOFT, true).apply { gravity = Gravity.CENTER }, lp(dp(180), dp(58)))
        page.addView(header)
        root.addView(page)
        body = page
        setContentView(root)
        return page
    }

    private fun showHome() {
        val page = basePage("TvMax")
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(space(1), lp(0, 1, 1f))
        top.addView(text("Playlist : $playlistName", 14, SOFT, false).apply { gravity = Gravity.CENTER }, lp(dp(300), dp(34)))
        page.addView(top, lp(-1, dp(34)))

        val mainRow = LinearLayout(this).apply { gravity = Gravity.CENTER }
        val live = heroButton("▣", "En direct") { showLive() }
        mainRow.addView(live, lp(dp(330), dp(330)))
        mainRow.addView(space(dp(20)), lp(dp(20), dp(1)))

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val row1 = LinearLayout(this)
        row1.addView(tileButton("▶", "Films") { showMovies() }, lp(dp(190), dp(145)))
        row1.addView(space(dp(14)), lp(dp(14), 1))
        row1.addView(tileButton("▤", "Séries") { showSeries() }, lp(dp(190), dp(145)))
        val row2 = LinearLayout(this).apply { }
        row2.addView(tileButton("♙", "Compte") { showAccount() }, lp(dp(190), dp(145)))
        row2.addView(space(dp(14)), lp(dp(14), 1))
        row2.addView(tileButton("↕", "Changer la liste") { showPlaylists() }, lp(dp(190), dp(145)))
        center.addView(row1); center.addView(space(dp(16)), lp(-1, dp(16))); center.addView(row2)
        mainRow.addView(center)
        mainRow.addView(space(dp(22)), lp(dp(22), 1))

        val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        right.addView(actionButton("⚙", "Paramètres") { showSettings() }, lp(dp(290), dp(86)))
        right.addView(space(dp(13)), lp(-1, dp(13)))
        right.addView(actionButton("↻", "Recharger") { reloadHome() }, lp(dp(290), dp(86)))
        right.addView(space(dp(13)), lp(-1, dp(13)))
        right.addView(actionButton("⎋", "Quitter") { finish() }, lp(dp(290), dp(86)))
        mainRow.addView(right)
        page.addView(mainRow, lp(-1, dp(370)))

        val bottom = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        bottom.addView(text("TvMax", 15, SOFT, true), lp(dp(110), dp(35)))
        bottom.addView(text("  Accès rapide : En direct  •  Films  •  Séries  •  Paramètres", 13, DIM, false), lp(0, dp(35), 1f))
        bottom.addView(text("V7.0", 13, WHITE, true).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }, lp(dp(70), dp(35)))
        page.addView(bottom, lp(-1, dp(42)))
    }

    private fun reloadHome() {
        Toast.makeText(this, "Actualisation…", Toast.LENGTH_SHORT).show()
        if (server.isNotBlank()) loadType("live", false)
    }

    private fun showLive() = loadType("live", true)
    private fun showMovies() = loadType("movie", true)
    private fun showSeries() = loadType("series", true)

    private fun loadType(type: String, visible: Boolean) {
        val title = when (type) { "live" -> "En direct"; "movie" -> "Films"; else -> "Séries" }
        val page = basePage(title, true)
        val tools = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        val search = input("Rechercher…", "")
        tools.addView(search, lp(0, dp(54), 1f))
        tools.addView(space(dp(15)), lp(dp(15), 1))
        tools.addView(smallButton("★ Favoris") { renderItems(allItems.filter { favorites.contains(it.id) }) }, lp(dp(150), dp(54)))
        page.addView(tools, lp(-1, dp(58)))
        val status = text("Chargement…", 13, SOFT, false)
        page.addView(status, lp(-1, dp(36)))
        lifecycleScope.launch {
            try {
                val endpoint = when (type) { "movie" -> "get_vod_streams"; "series" -> "get_series"; else -> "get_live_streams" }
                val raw = withContext(Dispatchers.IO) {
                    URL("$server/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=$endpoint").readText()
                }
                allItems = parse(raw, type).toMutableList()
                status.text = "${allItems.size} contenus"
                renderItems(allItems)
                search.setOnEditorActionListener { _, _, _ ->
                    renderItems(allItems.filter { it.name.contains(search.text.toString(), true) }); true
                }
            } catch (e: Exception) { status.text = "Impossible de charger les contenus" }
        }
    }

    private fun renderItems(items: List<TvItem>) {
        while (body.childCount > 3) body.removeViewAt(body.childCount - 1)
        val scroll = ScrollView(this)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        items.take(100).forEachIndexed { index, item ->
            if (index % 5 == 0) { row = LinearLayout(this); grid.addView(row, lp(-1, dp(190))) }
            row!!.addView(contentCard(item), lp(0, dp(178), 1f))
            if (index % 5 != 4) row!!.addView(space(dp(12)), lp(dp(12), 1))
        }
        scroll.addView(grid)
        body.addView(scroll, lp(-1, 0, 1f))
    }

    private fun contentCard(item: TvItem): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(7), dp(7), dp(7), dp(7))
            background = focusBackground(false)
            isFocusable = true
            isClickable = true
            setOnClickListener { play(item) }
            setOnLongClickListener { toggleFavorite(item); true }
            setOnFocusChangeListener { v, has -> v.background = focusBackground(has) }
        }
        val image = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0x55100A45) }
        if (item.logo.isNotBlank()) ImageLoader(this).enqueue(ImageRequest.Builder(this).data(item.logo).target(image).build())
        box.addView(image, lp(-1, dp(110)))
        box.addView(text(item.name, 13, WHITE, true).apply { maxLines = 2 }, lp(-1, dp(44)))
        return box
    }

    private fun showSettings() {
        val page = basePage("Paramètres", true)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val entries = listOf(
            SettingItem("▣", "Ajouter une liste de lecture") { showPlaylists() },
            SettingItem("♙", "Contrôle parental") { toast("Contrôle parental") },
            SettingItem("↕", "Changer la liste de lecture") { showPlaylists() },
            SettingItem("文", "Changer la langue") { toast("Français") },
            SettingItem("▦", "Changer la disposition") { toast("Disposition TV") },
            SettingItem("◉", "Masquer les catégories en direct") { toast("Option enregistrée") },
            SettingItem("◉", "Masquer les catégories VOD") { toast("Option enregistrée") },
            SettingItem("◉", "Masquer les catégories Séries") { toast("Option enregistrée") },
            SettingItem("▣", "Effacer historique des chaînes") { clearHistory() },
            SettingItem("▣", "Effacer historique des films") { clearHistory() },
            SettingItem("▣", "Effacer historique des séries") { clearHistory() },
            SettingItem("A↕", "Tri des chaînes en direct") { toast("Tri A → Z") },
            SettingItem("TV", "Format de diffusion TV en Direct") { toast("Automatique") },
            SettingItem("▶", "Lecteurs externes") { toast("Lecteur TvMax") },
            SettingItem("↻", "Automatique") { toast("Activé") },
            SettingItem("◷", "Format de l'heure") { toast("24 heures") },
            SettingItem("▤", "Paramètres des sous-titres") { toast("Sous-titres") },
            SettingItem("▣", "Sélectionner le Type d'Appareil") { toast("Android TV") },
            SettingItem("♙", "Contrôle parental désactivé") { toast("Désactivé") },
            SettingItem("↓", "Mettre à jour maintenant") { toast("TvMax est à jour") }
        )
        for (r in 0 until 5) {
            val row = LinearLayout(this)
            for (c in 0 until 4) {
                val idx = r * 4 + c
                if (idx < entries.size) {
                    val e = entries[idx]
                    row.addView(settingsButton(e.first, e.second, e.third), lp(0, dp(78), 1f))
                    if (c < 3) row.addView(space(dp(12)), lp(dp(12), 1))
                }
            }
            grid.addView(row, lp(-1, dp(78)))
            if (r < 4) grid.addView(space(dp(11)), lp(-1, dp(11)))
        }
        page.addView(grid, lp(-1, dp(435)))
        page.addView(text("Playlist : $playlistName", 14, SOFT, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(30)))
        page.addView(text("TvMax  •  Android TV  •  V7.0", 12, DIM, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(28)))
    }

    private fun showPlaylists() {
        val page = basePage("Listes de lecture", true)
        val panel = rounded(0x99160E58.toInt(), 24f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(28), dp(20), dp(28), dp(20)) }
        panel.addView(text("Liste actuelle", 18, WHITE, true), lp(-1, dp(40)))
        panel.addView(text(playlistName, 15, SOFT, false), lp(-1, dp(38)))
        val add = tvButton("AJOUTER / MODIFIER LA LISTE") { showLogin() }
        panel.addView(add, lp(dp(320), dp(58)))
        page.addView(panel, lp(dp(700), dp(210)))
        add.requestFocus()
    }

    private fun showAccount() {
        val page = basePage("Compte", true)
        val panel = rounded(0x99160E58.toInt(), 24f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(30), dp(22), dp(30), dp(22)) }
        panel.addView(text("$username", 22, WHITE, true), lp(-1, dp(45)))
        panel.addView(text(server, 14, SOFT, false), lp(-1, dp(38)))
        panel.addView(text("Playlist : $playlistName", 14, DIM, false), lp(-1, dp(38)))
        val logout = tvButton("SE DÉCONNECTER") { prefs.edit().clear().apply(); showLogin() }
        panel.addView(logout, lp(dp(280), dp(58)))
        page.addView(panel, lp(dp(760), dp(270)))
        logout.requestFocus()
    }

    private fun clearHistory() {
        history.clear(); persist(); toast("Historique effacé")
    }

    private fun toggleFavorite(item: TvItem) {
        if (favorites.contains(item.id)) favorites.remove(item.id) else favorites.add(item.id)
        persist(); toast(if (favorites.contains(item.id)) "Ajouté aux favoris" else "Retiré des favoris")
    }

    private fun play(item: TvItem) {
        val path = if (item.type == "movie") "movie" else "live"
        val ext = if (item.type == "live") "ts" else item.extension.ifBlank { "mp4" }
        val url = "$server/$path/${Uri.encode(username)}/${Uri.encode(password)}/${item.id}.$ext"
        history.remove(item.id); history.add(0, item.id); history = history.take(30).toMutableList(); persist()
        player?.release(); player = ExoPlayer.Builder(this).build()
        val pv = PlayerView(this).apply { player = this@MainActivity.player; useController = true }
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(pv); d.setOnDismissListener { player?.release(); player = null }; d.show()
        player?.setMediaItem(MediaItem.fromUri(url)); player?.prepare(); player?.playWhenReady = true
    }

    private fun parse(raw: String, type: String): List<TvItem> {
        val arr = JSONArray(raw)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("stream_id", o.optString("series_id", i.toString()))
                add(TvItem(id, o.optString("name", "Sans titre"), o.optString("stream_icon", o.optString("cover", "")), type, o.optString("container_extension", "mp4"), o.optString("category_id", "")))
            }
        }
    }

    private fun persist() { prefs.edit().putStringSet("favorites", favorites).putStringSet("history", history.toSet()).apply() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun heroButton(icon: String, label: String, click: () -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(15), dp(15), dp(15), dp(15)); background = focusBackground(false); isFocusable = true; isClickable = true; setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) } }
        box.addView(text(icon, 64, WHITE, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(105)))
        box.addView(text(label, 23, WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(55)))
        return box
    }

    private fun tileButton(icon: String, label: String, click: () -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = focusBackground(false); isFocusable = true; isClickable = true; setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) } }
        box.addView(text(icon, 38, WHITE, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(65)))
        box.addView(text(label, 17, WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(45)))
        return box
    }

    private fun actionButton(icon: String, label: String, click: () -> Unit): View {
        val box = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = focusBackground(false); isFocusable = true; isClickable = true; setPadding(dp(18), 0, dp(18), 0); setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) } }
        box.addView(text(icon, 28, WHITE, false).apply { gravity = Gravity.CENTER }, lp(dp(52), dp(70)))
        box.addView(text(label, 16, WHITE, true), lp(0, dp(70), 1f))
        return box
    }

    private fun settingsButton(icon: String, label: String, click: () -> Unit): View {
        val box = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = focusBackground(false); isFocusable = true; isClickable = true; setPadding(dp(10), 0, dp(10), 0); setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) } }
        box.addView(text(icon, 23, WHITE, false).apply { gravity = Gravity.CENTER }, lp(dp(42), dp(65)))
        box.addView(text(label, 13, WHITE, true).apply { maxLines = 2 }, lp(0, dp(65), 1f))
        return box
    }

    private fun tvButton(label: String, click: () -> Unit): View = actionButton("", label, click)
    private fun smallButton(label: String, click: () -> Unit): View = actionButton("", label, click)

    private fun focusBackground(focused: Boolean): GradientDrawable {
        return GradientDrawable().apply {
            cornerRadius = dp(12).toFloat()
            setColor(if (focused) 0xFFF02A98.toInt() else 0xFFD51A82.toInt())
            setStroke(if (focused) dp(3) else dp(1), if (focused) FOCUS else 0x66FFFFFF)
        }
    }

    private fun tvGradient() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(BG_TOP, BG_MID, BG_BOTTOM)).apply { cornerRadius = 0f }
    private fun rounded(color: Int, radius: Float) = LinearLayout(this).apply { background = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() } }
    private fun input(hint: String, value: String) = EditText(this).apply { this.hint = hint; setText(value); setTextColor(WHITE); setHintTextColor(DIM); textSize = 16f; isSingleLine = true; setPadding(dp(16), 0, dp(16), 0); background = GradientDrawable().apply { setColor(0xAA0D0A36.toInt()); cornerRadius = dp(10).toFloat(); setStroke(dp(1), 0x66FFFFFF) } }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER_VERTICAL; includeFontPadding = true }
    private fun space(h: Int) = Space(this)
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dp(v: Float) = (v * resources.displayMetrics.density)
}
