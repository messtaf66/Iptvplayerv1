package com.tvmax.player.ui
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import com.tvmax.player.data.XtreamApi
import com.tvmax.player.model.*
import kotlinx.coroutines.*
class CatalogActivity:Activity(){private val scope=CoroutineScope(SupervisorJob()+Dispatchers.Main);override fun onDestroy(){scope.cancel();super.onDestroy()}
 override fun onCreate(b:Bundle?){super.onCreate(b);showLoading();val kind=intent.getStringExtra("kind")?:"live";scope.launch{try{val c=loadConfig();val api=XtreamApi(c);val cats=when(kind){"movies"->api.vodCategories();"series"->api.seriesCategories();else->api.liveCategories()};showCatalog(kind,cats,api)}catch(e:Exception){showError(e.message?:"Erreur")}}}
 private fun loadConfig()=XtreamConfig("http://example.com:8080","","" )
 private fun showLoading(){val t=TextView(this);t.text="Chargement…";t.textSize=28f;t.setTextColor(Color.WHITE);t.gravity=Gravity.CENTER;setContentView(t)}
 private fun showError(s:String){val t=TextView(this);t.text="Aucune playlist configurée.\n\nParamètres → Ajouter une playlist";t.textSize=24f;t.setTextColor(Color.WHITE);t.gravity=Gravity.CENTER;setContentView(t)}
 private fun showCatalog(kind:String,cats:List<Category>,api:XtreamApi){val root=LinearLayout(this);root.orientation=LinearLayout.HORIZONTAL;root.setPadding(25,25,25,25);root.setBackgroundColor(Color.rgb(9,11,34));val left=LinearLayout(this);left.orientation=LinearLayout.VERTICAL;left.layoutParams=LinearLayout.LayoutParams(310,-1);val right=TextView(this);right.setTextColor(Color.WHITE);right.textSize=22f;right.gravity=Gravity.CENTER;right.text="Sélectionnez une catégorie";root.addView(left);root.addView(right,LinearLayout.LayoutParams(0,-1,1f));cats.forEach{cat->val b=Button(this);b.text=cat.name;b.isFocusable=true;b.setTextColor(Color.WHITE);b.background=getDrawable(com.tvmax.player.R.drawable.focus_bg);b.setOnClickListener{scope.launch{val items=when(kind){"movies"->api.vod(cat.id);"series"->api.series(cat.id);else->api.live(cat.id)};right.text=items.take(60).joinToString("\n\n"){it.name}}};left.addView(b,LinearLayout.LayoutParams(-1,65).apply{setMargins(0,4,0,4)})};setContentView(root)} }
