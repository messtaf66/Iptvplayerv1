package com.example.iptvplayer

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import androidx.compose.ui.viewinterop.AndroidView

data class Channel(
    val name: String,
    val url: String,
    val group: String = "Autres",
    val logo: String? = null
)

class MainViewModel : androidx.lifecycle.ViewModel() {
    var channels by mutableStateOf<List<Channel>>(emptyList())
        private set
    var favorites by mutableStateOf<Set<String>>(emptySet())
        private set
    var selectedGroup by mutableStateOf("Toutes")
    var selectedChannel by mutableStateOf<Channel?>(null)
    var message by mutableStateOf("Ajoute une playlist M3U pour commencer.")

    fun loadM3u(text: String) {
        val result = mutableListOf<Channel>()
        var name = ""
        var group = "Autres"
        var logo: String? = null

        text.lineSequence().forEach { raw ->
            val line = raw.trim()
            if (line.startsWith("#EXTINF", ignoreCase = true)) {
                name = line.substringAfterLast(",").trim().ifEmpty { "Chaîne" }
                group = Regex("""group-title="([^"]*)"""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1)?.ifEmpty { "Autres" } ?: "Autres"
                logo = Regex("""tvg-logo="([^"]*)"""", RegexOption.IGNORE_CASE)
                    .find(line)?.groupValues?.getOrNull(1)
            } else if (line.isNotEmpty() && !line.startsWith("#") && name.isNotEmpty()) {
                result += Channel(name, line, group, logo)
                name = ""
                group = "Autres"
                logo = null
            }
        }

        channels = result
        message = if (result.isEmpty()) "Aucune chaîne trouvée." else "${result.size} chaîne(s) chargée(s)."
        selectedGroup = "Toutes"
    }

    fun toggleFavorite(channel: Channel) {
        favorites = if (channel.name in favorites) favorites - channel.name
        else favorites + channel.name
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                IptvApp()
            }
        }
    }
}

@Composable
fun IptvApp(vm: MainViewModel = viewModel()) {
    var url by remember { mutableStateOf("") }
    var search by remember { mutableStateOf("") }
    var showPlayer by remember { mutableStateOf(false) }

    val groups = remember(vm.channels) {
        listOf("Toutes") + vm.channels.map { it.group }.distinct().sorted()
    }

    val visibleChannels = vm.channels.filter {
        (vm.selectedGroup == "Toutes" || it.group == vm.selectedGroup) &&
        (search.isBlank() || it.name.contains(search, ignoreCase = true))
    }

    if (showPlayer && vm.selectedChannel != null) {
        VideoScreen(vm.selectedChannel!!, onBack = { showPlayer = false })
        return
    }

    Column(
        modifier = Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("IPTV Player", style = MaterialTheme.typography.headlineLarge)

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlinedTextField(
                value = url,
                onValueChange = { url = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                label = { Text("URL de la playlist M3U") },
                placeholder = { Text("https://exemple.com/playlist.m3u") }
            )
            Button(onClick = {
                if (url.isNotBlank()) {
                    Thread {
                        try {
                            val text = java.net.URL(url).readText()
                            vm.loadM3u(text)
                        } catch (e: Exception) {
                            vm.message = "Erreur de chargement : ${e.message ?: "URL inaccessible"}"
                        }
                    }.start()
                }
            }) { Text("Charger") }
        }

        Text(vm.message)

        if (vm.channels.isNotEmpty()) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                groups.take(8).forEach { group ->
                    FilterChip(
                        selected = vm.selectedGroup == group,
                        onClick = { vm.selectedGroup = group },
                        label = { Text(group) }
                    )
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Rechercher une chaîne") }
            )

            LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                items(visibleChannels) { channel ->
                    Row(
                        modifier = Modifier.fillMaxWidth()
                            .clickable {
                                vm.selectedChannel = channel
                                showPlayer = true
                            }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(channel.name, style = MaterialTheme.typography.titleMedium)
                            Text(channel.group, style = MaterialTheme.typography.bodySmall)
                        }
                        Text(
                            if (channel.name in vm.favorites) "★" else "☆",
                            modifier = Modifier.clickable { vm.toggleFavorite(channel) }
                                .padding(10.dp),
                            style = MaterialTheme.typography.headlineSmall
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun VideoScreen(channel: Channel, onBack: () -> Unit) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val player = remember(channel.url) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(channel.url))
            prepare()
            playWhenReady = true
        }
    }

    DisposableEffect(player) {
        onDispose { player.release() }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player } },
            modifier = Modifier.fillMaxSize()
        )
        Button(
            onClick = onBack,
            modifier = Modifier.padding(20.dp).align(Alignment.TopStart)
        ) {
            Text("← Retour")
        }
    }
}
