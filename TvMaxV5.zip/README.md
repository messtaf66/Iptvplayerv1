# TvMax V5

Lecteur IPTV Android TV basé sur Xtream Codes.

Nouveautés V5 :
- Historique persistant des contenus regardés
- Écran « Reprendre »
- Jusqu’à 12 contenus conservés dans l’historique
- Effacement de l’historique depuis l’application
- V4 conservée comme base fonctionnelle

Installation : compiler avec le workflow GitHub Actions puis installer l’APK sur NVIDIA Shield.
