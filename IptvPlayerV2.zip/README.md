# IPTV Player V2

Android TV IPTV player prototype for NVIDIA Shield.

Features:
- Xtream Codes login (server, username, password)
- Live TV with categories
- Movies with categories
- Series with categories, seasons and episodes
- Search
- Favorites
- Media3/ExoPlayer playback
- Basic short EPG for Live TV
- Android TV friendly landscape interface

Use only IPTV services and streams you are authorized to access.
