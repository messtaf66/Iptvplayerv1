package com.tvmax.player.ui

import androidx.appcompat.app.AppCompatActivity
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.lifecycle.lifecycleScope
import com.tvmax.player.data.PlaylistStore
import com.tvmax.player.data.SavedPlaylist
import com.tvmax.player.data.XtreamApi
import com.tvmax.player.model.XtreamConfig
import kotlinx.coroutines.launch

class PlaylistActivity : AppCompatActivity() {
    private lateinit var list: LinearLayout
    private lateinit var status: TextView
    private lateinit var host: EditText
    private lateinit var user: EditText
    private lateinit var pass: EditText
    private lateinit var name: EditText
    private lateinit var m3uUrl: EditText
    private var xtreamMode = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        build()
    }

    private fun build() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(50, 28, 50, 28)
            setBackgroundColor(Color.rgb(8, 10, 38))
        }
        val title = TextView(this).apply { text = "Listes de lecture"; textSize = 34f; setTextColor(Color.WHITE); gravity = Gravity.CENTER }
        root.addView(title, LinearLayout.LayoutParams(-1, 70))

        val tabs = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        val xt = button("Xtream Codes") { xtreamMode = true; showForm() }
        val m3u = button("Lien M3U") { xtreamMode = false; showForm() }
        tabs.addView(xt, LinearLayout.LayoutParams(0, 62, 1f).apply { setMargins(5, 5, 5, 5) })
        tabs.addView(m3u, LinearLayout.LayoutParams(0, 62, 1f).apply { setMargins(5, 5, 5, 5) })
        root.addView(tabs)

        name = field("Nom de la playlist")
        host = field("Serveur Xtream (ex : http://serveur:8080)")
        user = field("Nom d'utilisateur")
        pass = field("Mot de passe")
        pass.inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        m3uUrl = field("URL M3U complète")
        root.addView(name); root.addView(host); root.addView(user); root.addView(pass); root.addView(m3uUrl)

        val save = button("✓  Tester et ajouter") { savePlaylist() }
        root.addView(save, LinearLayout.LayoutParams(-1, 72).apply { setMargins(0, 12, 0, 12) })
        status = TextView(this).apply { textSize = 17f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER }
        root.addView(status, LinearLayout.LayoutParams(-1, 60))

        val head = TextView(this).apply { text = "Playlists enregistrées"; textSize = 24f; setTextColor(Color.WHITE) }
        root.addView(head, LinearLayout.LayoutParams(-1, 55))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(ScrollView(this).apply { addView(list) }, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        showForm()
        refreshList()
    }

    private fun showForm() {
        host.visibility = if (xtreamMode) View.VISIBLE else View.GONE
        user.visibility = if (xtreamMode) View.VISIBLE else View.GONE
        pass.visibility = if (xtreamMode) View.VISIBLE else View.GONE
        m3uUrl.visibility = if (xtreamMode) View.GONE else View.VISIBLE
    }

    private fun savePlaylist() {
        val playlistName = name.text.toString().trim()
        if (playlistName.isBlank()) { status.text = "Entre un nom pour la playlist."; return }
        if (!xtreamMode) {
            val url = m3uUrl.text.toString().trim()
            if (url.isBlank()) { status.text = "Entre l'URL M3U."; return }
            val item = SavedPlaylist(playlistName, "m3u", url = url)
            PlaylistStore.add(this, item); PlaylistStore.select(this, item); status.text = "Playlist M3U ajoutée."; refreshList(); return
        }
        val h = host.text.toString().trim().trimEnd('/')
        val u = user.text.toString().trim(); val p = pass.text.toString()
        if (h.isBlank() || u.isBlank() || p.isBlank()) { status.text = "Serveur, utilisateur et mot de passe sont obligatoires."; return }
        status.text = "Connexion au serveur…"
        lifecycleScope.launch {
            val ok = XtreamApi(XtreamConfig(h, u, p)).testConnection()
            if (ok) {
                val item = SavedPlaylist(playlistName, "xtream", host = h, username = u, password = p)
                PlaylistStore.add(this@PlaylistActivity, item); PlaylistStore.select(this@PlaylistActivity, item)
                status.text = "✓ Connexion réussie — playlist ajoutée."
                refreshList()
            } else status.text = "✕ Impossible de se connecter à ce serveur."
        }
    }

    private fun refreshList() {
        if (!::list.isInitialized) return
        list.removeAllViews()
        PlaylistStore.get(this).forEach { item ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val label = TextView(this).apply { text = "${item.name}  •  ${item.type.uppercase()}"; textSize = 18f; setTextColor(Color.WHITE); isFocusable = true; setPadding(18, 0, 18, 0) }
            row.addView(label, LinearLayout.LayoutParams(0, 62, 1f))
            val use = button("Utiliser") { PlaylistStore.select(this, item); status.text = "Playlist sélectionnée : ${item.name}" }
            val del = button("Supprimer") { PlaylistStore.remove(this, item.name); refreshList() }
            row.addView(use, LinearLayout.LayoutParams(150, 58).apply { setMargins(5, 2, 5, 2) })
            row.addView(del, LinearLayout.LayoutParams(150, 58).apply { setMargins(5, 2, 5, 2) })
            list.addView(row)
        }
    }

    private fun field(hint: String) = EditText(this).apply {
        this.hint = hint; setTextColor(Color.WHITE); setHintTextColor(Color.LTGRAY); textSize = 17f; isFocusable = true
        setSingleLine(true); setPadding(18, 0, 18, 0)
        setBackgroundColor(Color.rgb(30, 35, 90))
        layoutParams = LinearLayout.LayoutParams(-1, 58).apply { setMargins(0, 5, 0, 5) }
    }

    private fun button(text: String, click: () -> Unit) = Button(this).apply {
        this.text = text; textSize = 17f; setTextColor(Color.WHITE); isFocusable = true
        background = getDrawable(com.tvmax.player.R.drawable.focus_bg); setOnClickListener { click() }
    }
}
