package com.example.iptvplayer

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

data class XtreamItem(
    val id: String,
    val name: String,
    val categoryId: String = "",
    val categoryName: String = "",
    val icon: String? = null,
    val streamUrl: String = "",
    val isSeries: Boolean = false
)

data class EpgItem(val title: String, val start: String, val end: String)

class IptvViewModel : ViewModel() {
    var server by mutableStateOf("")
    var username by mutableStateOf("")
    var password by mutableStateOf("")

    var connected by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var message by mutableStateOf("Connecte ton compte Xtream Codes.")
    var section by mutableStateOf("Live TV")

    var categories by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var items by mutableStateOf<List<XtreamItem>>(emptyList())
    var favorites by mutableStateOf<Set<String>>(emptySet())
    var selectedItem by mutableStateOf<XtreamItem?>(null)
    var seriesEpisodes by mutableStateOf<List<XtreamItem>>(emptyList())
    var epg by mutableStateOf<List<EpgItem>>(emptyList())

    private fun base(): String = server.trim().removeSuffix("/")

    private suspend fun getJson(path: String): String = withContext(Dispatchers.IO) {
        val url = URL(path)
        val c = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 20000
            requestMethod = "GET"
        }
        try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    private fun api(action: String): String {
        return "${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=$action"
    }

    fun connect(scope: kotlinx.coroutines.CoroutineScope) {
        if (server.isBlank() || username.isBlank() || password.isBlank()) {
            message = "Renseigne le serveur, l'utilisateur et le mot de passe."
            return
        }
        scope.launch {
            loading = true
            try {
                val raw = getJson("${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}")
                val obj = JSONObject(raw)
                val info = obj.optJSONObject("user_info")
                if (info == null || info.optString("auth") != "1") {
                    connected = false
                    message = "Connexion refusée. Vérifie tes identifiants."
                } else {
                    connected = true
                    message = "Connecté : ${info.optString("status", "actif")}"
                    loadSection(scope, "Live TV")
                }
            } catch (e: Exception) {
                connected = false
                message = "Erreur : ${e.message ?: "serveur inaccessible"}"
            } finally {
                loading = false
            }
        }
    }

    fun loadSection(scope: kotlinx.coroutines.CoroutineScope, target: String) {
        if (!connected) return
        section = target
        scope.launch {
            loading = true
            try {
                when (target) {
                    "Live TV" -> {
                        categories = parseCategories(getJson(api("get_live_categories")))
                        items = parseLive(getJson(api("get_live_streams")))
                    }
                    "Films" -> {
                        categories = parseCategories(getJson(api("get_vod_categories")))
                        items = parseVod(getJson(api("get_vod_streams")))
                    }
                    "Séries" -> {
                        categories = parseCategories(getJson(api("get_series_categories")))
                        items = parseSeries(getJson(api("get_series")))
                    }
                }
                message = "${items.size} élément(s) chargé(s)."
            } catch (e: Exception) {
                message = "Erreur de chargement : ${e.message ?: "inconnue"}"
            } finally {
                loading = false
            }
        }
    }

    private fun parseCategories(raw: String): List<Pair<String, String>> {
        val a = JSONArray(raw)
        val out = mutableListOf<Pair<String, String>>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            out += o.optString("category_id") to o.optString("category_name", "Autres")
        }
        return out
    }

    private fun parseLive(raw: String): List<XtreamItem> {
        val a = JSONArray(raw)
        val out = mutableListOf<XtreamItem>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val id = o.optString("stream_id")
            out += XtreamItem(
                id = id,
                name = o.optString("name", "Chaîne"),
                categoryId = o.optString("category_id"),
                icon = o.optString("stream_icon").takeIf { it.isNotBlank() },
                streamUrl = "${base()}/live/${Uri.encode(username)}/${Uri.encode(password)}/$id.ts"
            )
        }
        return out
    }

    private fun parseVod(raw: String): List<XtreamItem> {
        val a = JSONArray(raw)
        val out = mutableListOf<XtreamItem>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val id = o.optString("stream_id")
            out += XtreamItem(
                id = id,
                name = o.optString("name", "Film"),
                categoryId = o.optString("category_id"),
                icon = o.optString("stream_icon").takeIf { it.isNotBlank() },
                streamUrl = "${base()}/movie/${Uri.encode(username)}/${Uri.encode(password)}/$id.${o.optString("container_extension", "mp4")}"
            )
        }
        return out
    }

    private fun parseSeries(raw: String): List<XtreamItem> {
        val a = JSONArray(raw)
        val out = mutableListOf<XtreamItem>()
        for (i in 0 until a.length()) {
            val o = a.getJSONObject(i)
            val id = o.optString("series_id")
            out += XtreamItem(
                id = id,
                name = o.optString("name", "Série"),
                categoryId = o.optString("category_id"),
                icon = o.optString("cover").takeIf { it.isNotBlank() },
                isSeries = true
            )
        }
        return out
    }

    fun openSeries(scope: kotlinx.coroutines.CoroutineScope, series: XtreamItem) {
        scope.launch {
            loading = true
            try {
                val raw = getJson("${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=get_series_info&series_id=${Uri.encode(series.id)}")
                val obj = JSONObject(raw)
                val episodesObj = obj.optJSONObject("episodes")
                val out = mutableListOf<XtreamItem>()
                if (episodesObj != null) {
                    val seasonKeys = episodesObj.keys()
                    while (seasonKeys.hasNext()) {
                        val seasonKey = seasonKeys.next()
                        val season = episodesObj.optJSONArray(seasonKey) ?: continue
                        for (e in 0 until season.length()) {
                            val ep = season.getJSONObject(e)
                            val id = ep.optString("id")
                            val ext = ep.optString("container_extension", "mp4")
                            out += XtreamItem(
                                id = id,
                                name = "S${ep.optString("season", seasonKey)} E${ep.optString("episode_num", "?")} — ${ep.optString("title", "Épisode")}",
                                streamUrl = "${base()}/series/${Uri.encode(username)}/${Uri.encode(password)}/$id.$ext"
                            )
                        }
                    }
                }
                seriesEpisodes = out
                selectedItem = null
                message = "${out.size} épisode(s) trouvé(s)."
            } catch (e: Exception) {
                message = "Impossible de charger les épisodes."
            } finally {
                loading = false
            }
        }
    }

    fun loadEpg(scope: kotlinx.coroutines.CoroutineScope, item: XtreamItem) {
        if (section != "Live TV") return
        scope.launch {
            try {
                val raw = getJson("${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=get_short_epg&stream_id=${Uri.encode(item.id)}&limit=5")
                val root = JSONObject(raw)
                val a = root.optJSONArray("epg_list") ?: JSONArray(raw)
                val out = mutableListOf<EpgItem>()
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    out += EpgItem(o.optString("title"), o.optString("start"), o.optString("end"))
                }
                epg = out
            } catch (_: Exception) {
                epg = emptyList()
            }
        }
    }

    fun toggleFavorite(item: XtreamItem) {
        favorites = if (item.id in favorites) favorites - item.id else favorites + item.id
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                IptvApp()
            }
        }
    }
}

@Composable
fun IptvApp(vm: IptvViewModel = viewModel()) {
    val scope = rememberCoroutineScope()
    val context = LocalContext.current
    val prefs = remember { context.getSharedPreferences("iptv", Context.MODE_PRIVATE) }

    var server by remember { mutableStateOf(prefs.getString("server", "") ?: "") }
    var user by remember { mutableStateOf(prefs.getString("user", "") ?: "") }
    var pass by remember { mutableStateOf(prefs.getString("pass", "") ?: "") }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Toutes") }
    var showPlayer by remember { mutableStateOf(false) }
    var showEpg by remember { mutableStateOf(false) }

    if (showPlayer && vm.selectedItem != null) {
        PlayerScreen(
            item = vm.selectedItem!!,
            onBack = { showPlayer = false },
            onEpg = {
                showEpg = true
                vm.loadEpg(scope, vm.selectedItem!!)
            },
            epg = vm.epg,
            showEpg = showEpg,
            closeEpg = { showEpg = false }
        )
        return
    }

    Column(
        Modifier.fillMaxSize().padding(22.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("TvMax", style = MaterialTheme.typography.headlineMedium)

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(server, { server = it }, Modifier.weight(1f), singleLine = true, label = { Text("Serveur") }, placeholder = { Text("http://serveur:port") })
            OutlinedTextField(user, { user = it }, Modifier.weight(.55f), singleLine = true, label = { Text("Utilisateur") })
            OutlinedTextField(pass, { pass = it }, Modifier.weight(.55f), singleLine = true, label = { Text("Mot de passe") })
            Button(onClick = {
                vm.server = server
                vm.username = user
                vm.password = pass
                prefs.edit().putString("server", server).putString("user", user).putString("pass", pass).apply()
                vm.connect(scope)
            }) { Text("Connexion") }
        }

        if (vm.connected) {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("Live TV", "Films", "Séries").forEach {
                    FilterChip(selected = vm.section == it, onClick = {
                        category = "Toutes"
                        search = ""
                        vm.loadSection(scope, it)
                    }, label = { Text(it) })
                }
            }

            val categoryNames = listOf("Toutes") + vm.categories.map { it.second }.distinct()
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                categoryNames.take(10).forEach { name ->
                    FilterChip(selected = category == name, onClick = { category = name }, label = { Text(name) })
                }
            }

            OutlinedTextField(
                value = search,
                onValueChange = { search = it },
                Modifier.fillMaxWidth(),
                singleLine = true,
                label = { Text("Rechercher") }
            )

            val visible = vm.items.filter {
                (category == "Toutes" || it.categoryName == category || vm.categories.firstOrNull { c -> c.first == it.categoryId }?.second == category) &&
                (search.isBlank() || it.name.contains(search, ignoreCase = true))
            }

            if (vm.section == "Séries" && vm.seriesEpisodes.isNotEmpty()) {
                Text("Épisodes", style = MaterialTheme.typography.titleLarge)
                LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(vm.seriesEpisodes) { ep ->
                        ListItem(
                            headlineContent = { Text(ep.name) },
                            modifier = Modifier.clickable {
                                vm.selectedItem = ep
                                showPlayer = true
                            }
                        )
                    }
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(220.dp),
                    modifier = Modifier.weight(1f),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(visible) { item ->
                        Card(Modifier.fillMaxWidth().clickable {
                            if (item.isSeries) vm.openSeries(scope, item)
                            else {
                                vm.selectedItem = item
                                showPlayer = true
                            }
                        }) {
                            Column(Modifier.padding(12.dp)) {
                                Text(item.name, style = MaterialTheme.typography.titleMedium)
                                Text(
                                    if (item.id in vm.favorites) "★ Favori" else "☆ Favori",
                                    modifier = Modifier.clickable { vm.toggleFavorite(item) }.padding(top = 8.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        if (vm.message.isNotBlank()) Text(vm.message)
        if (vm.loading) LinearProgressIndicator(Modifier.fillMaxWidth())
    }
}

@Composable
fun PlayerScreen(
    item: XtreamItem,
    onBack: () -> Unit,
    onEpg: () -> Unit,
    epg: List<EpgItem>,
    showEpg: Boolean,
    closeEpg: () -> Unit
) {
    val context = LocalContext.current
    val player = remember(item.streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(item.streamUrl))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player } },
            modifier = Modifier.fillMaxSize()
        )
        Row(Modifier.align(Alignment.TopStart).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onBack) { Text("← Retour") }
            if (item.streamUrl.contains("/live/")) Button(onClick = onEpg) { Text("EPG") }
        }

        if (showEpg) {
            Card(Modifier.align(Alignment.Center).fillMaxWidth(.75f)) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Programme", style = MaterialTheme.typography.headlineSmall)
                    if (epg.isEmpty()) Text("Aucun programme disponible.")
                    epg.forEach { p ->
                        Text(p.title)
                        Text("${p.start} → ${p.end}", style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = closeEpg) { Text("Fermer") }
                }
            }
        }
    }
}
