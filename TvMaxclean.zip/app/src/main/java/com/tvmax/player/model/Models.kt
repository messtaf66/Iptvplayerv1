package com.tvmax.player.model

data class XtreamConfig(val host:String,val username:String,val password:String)
data class Category(val id:String,val name:String)
data class StreamItem(val id:String,val name:String,val categoryId:String,val icon:String?=null,val rating:String?=null,val plot:String?=null,val url:String?=null)
