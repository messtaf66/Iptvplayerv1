# TvMax V6

Refonte complète de l'interface Android TV.

- Accueil type dashboard
- Navigation latérale
- Hero "À la une"
- Lignes de contenus
- Live TV, Films, Séries
- Catégories
- Recherche instantanée
- Favoris persistants
- Historique / reprendre
- Logos et affiches depuis Xtream
- Lecteur plein écran Media3
- EPG court
- Paramètres
- Navigation télécommande Shield

Utiliser uniquement des comptes et flux auxquels vous êtes autorisé à accéder.
