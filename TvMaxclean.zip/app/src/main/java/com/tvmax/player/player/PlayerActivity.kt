package com.tvmax.player.player
import android.app.Activity
import android.os.Bundle
import android.view.*
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
class PlayerActivity:Activity(){private var player:ExoPlayer?=null;private lateinit var pv:PlayerView;override fun onCreate(b:Bundle?){super.onCreate(b);pv=PlayerView(this);pv.useController=true;setContentView(pv);player=ExoPlayer.Builder(this).build();pv.player=player;pv.requestFocus()};override fun onDestroy(){player?.release();super.onDestroy()}}
