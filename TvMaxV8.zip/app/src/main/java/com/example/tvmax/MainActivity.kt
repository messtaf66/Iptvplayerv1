package com.example.tvmax

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.request.ImageRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.URL
import java.util.Locale

private const val BG_TOP = 0xFF12248A.toInt()
private const val BG_MID = 0xFF3B1EAE.toInt()
private const val BG_BOTTOM = 0xFF14072F.toInt()
private const val CARD = 0xFFD91A86.toInt()
private const val CARD2 = 0xFFB91478.toInt()
private const val WHITE = 0xFFFFFFFF.toInt()
private const val SOFT = 0xFFEDEBFF.toInt()
private const val DIM = 0xFFC4C0E8.toInt()
private const val FOCUS = 0xFFFFF6A8.toInt()

private data class TvItem(
    val id: String,
    val name: String,
    val logo: String,
    val type: String,
    val extension: String = "mp4",
    val categoryId: String = "",
    val categoryName: String = "Autres",
    val rating: String = ""
)

private data class Category(val id: String, val name: String, val count: Int)
private data class Episode(val id: String, val title: String, val season: Int, val episode: Int, val image: String = "")

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var body: LinearLayout
    private var server = ""
    private var username = ""
    private var password = ""
    private var playlistName = "Ma playlist"
    private var allItems = mutableListOf<TvItem>()
    private var favorites = mutableSetOf<String>()
    private var history = mutableListOf<String>()
    private var player: ExoPlayer? = null
    private var previewPlayer: ExoPlayer? = null
    private var selectedLiveGroup = "Toutes"
    private var currentLiveItems = listOf<TvItem>()
    private var currentLiveChannel: TvItem? = null

    private val prefs by lazy { getSharedPreferences("tvmax8", Context.MODE_PRIVATE) }
    private val loader by lazy { ImageLoader(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        server = prefs.getString("server", "") ?: ""
        username = prefs.getString("user", "") ?: ""
        password = prefs.getString("pass", "") ?: ""
        playlistName = prefs.getString("playlist", "Ma playlist") ?: "Ma playlist"
        favorites = (prefs.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        history = (prefs.getStringSet("history", emptySet()) ?: emptySet()).toMutableList()
        if (server.isBlank()) showLogin() else showHome()
    }

    override fun onDestroy() {
        releasePlayers()
        super.onDestroy()
    }

    private fun showLogin() {
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(80), dp(30), dp(80), dp(30))
            background = tvGradient()
        }
        page.addView(text("TVMAX", 48, WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(72)))
        page.addView(text("Lecteur IPTV pour Android TV", 18, SOFT, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(40)))
        val panel = rounded(0xAA120C52.toInt(), 26f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(34), dp(26), dp(34), dp(26)) }
        val s = input("URL du serveur", server)
        val u = input("Nom d'utilisateur", username)
        val p = input("Mot de passe", password).apply { inputType = 0x81 }
        panel.addView(s, lp(-1, dp(58))); panel.addView(space(dp(10)), lp(-1, dp(10)))
        panel.addView(u, lp(-1, dp(58))); panel.addView(space(dp(10)), lp(-1, dp(10)))
        panel.addView(p, lp(-1, dp(58))); panel.addView(space(dp(16)), lp(-1, dp(16)))
        val connect = tvButton("SE CONNECTER") {
            server = s.text.toString().trim().removeSuffix("/")
            username = u.text.toString().trim()
            password = p.text.toString().trim()
            connect()
        }
        panel.addView(connect, lp(-1, dp(60)))
        page.addView(panel, lp(dp(650), dp(340)))
        page.addView(text("Utilisez uniquement des services et contenus auxquels vous êtes autorisé à accéder.", 12, DIM, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(45)))
        setContentView(page)
        connect.requestFocus()
    }

    private fun connect() {
        lifecycleScope.launch {
            try {
                val raw = api("player_api.php")
                val root = JSONObject(raw)
                if (!root.has("user_info")) error("Identifiants incorrects")
                prefs.edit().putString("server", server).putString("user", username).putString("pass", password).apply()
                showHome()
            } catch (e: Exception) {
                toast("Connexion impossible : ${e.message ?: "serveur indisponible"}")
            }
        }
    }

    private fun api(path: String, params: Map<String, String> = emptyMap()): String {
        val base = if (path.startsWith("http")) path else "$server/$path"
        val q = mutableListOf("username" to username, "password" to password)
        q.addAll(params.toList())
        val query = q.joinToString("&") { "${Uri.encode(it.first)}=${Uri.encode(it.second)}" }
        return URL("$base?$query").readText()
    }

    private fun page(title: String, showBack: Boolean = false): LinearLayout {
        releasePreview()
        root = FrameLayout(this).apply { background = tvGradient() }
        val p = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(34), dp(18), dp(34), dp(18))
        }
        val header = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        if (showBack) {
            header.addView(actionButton("‹", "Retour") { showHome() }, lp(dp(120), dp(48)))
            header.addView(space(dp(12)), lp(dp(12), 1))
        }
        header.addView(text(title, 24, WHITE, true).apply { gravity = Gravity.CENTER_VERTICAL }, lp(0, dp(48), 1f))
        header.addView(text("TVMAX  •  V8.0", 12, SOFT, true).apply { gravity = Gravity.RIGHT or Gravity.CENTER_VERTICAL }, lp(dp(150), dp(48)))
        p.addView(header)
        root.addView(p)
        body = p
        setContentView(root)
        return p
    }

    private fun navBar(selected: String): LinearLayout {
        val nav = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        listOf("Accueil", "En direct", "Films", "Séries").forEach { label ->
            val b = TextView(this).apply {
                text = label
                textSize = 15f
                setTextColor(if (label == selected) FOCUS else WHITE)
                setTypeface(typeface, Typeface.BOLD)
                gravity = Gravity.CENTER
                isFocusable = true
                setPadding(dp(14), 0, dp(14), 0)
                setOnClickListener {
                    when (label) { "Accueil" -> showHome(); "En direct" -> showLive(); "Films" -> showMovies(); "Séries" -> showSeries() }
                }
                setOnFocusChangeListener { v, has -> (v as TextView).setTextColor(if (has || label == selected) FOCUS else WHITE) }
            }
            nav.addView(b, lp(dp(100), dp(42)))
            nav.addView(text("|", 14, DIM, false).apply { gravity = Gravity.CENTER }, lp(dp(16), dp(42)))
        }
        val search = input("Rechercher…", "")
        nav.addView(search, lp(dp(310), dp(44)))
        return nav
    }

    private fun showHome() {
        val p = page("TvMax")
        p.addView(text("Playlist : $playlistName", 13, SOFT, false).apply { gravity = Gravity.RIGHT }, lp(-1, dp(30)))
        val row = LinearLayout(this).apply { gravity = Gravity.CENTER }
        row.addView(heroButton("▣", "En direct") { showLive() }, lp(dp(310), dp(300)))
        row.addView(space(dp(16)), lp(dp(16), 1))
        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val r1 = LinearLayout(this)
        r1.addView(tileButton("▶", "Films") { showMovies() }, lp(dp(175), dp(130)))
        r1.addView(space(dp(12)), lp(dp(12), 1))
        r1.addView(tileButton("▤", "Séries") { showSeries() }, lp(dp(175), dp(130)))
        val r2 = LinearLayout(this)
        r2.addView(tileButton("♙", "Compte") { showAccount() }, lp(dp(175), dp(130)))
        r2.addView(space(dp(12)), lp(dp(12), 1))
        r2.addView(tileButton("↕", "Changer la liste") { showPlaylists() }, lp(dp(175), dp(130)))
        center.addView(r1); center.addView(space(dp(12)), lp(-1, dp(12))); center.addView(r2)
        row.addView(center); row.addView(space(dp(16)), lp(dp(16), 1))
        val actions = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        actions.addView(actionButton("⚙", "Paramètres") { showSettings() }, lp(dp(245), dp(80)))
        actions.addView(space(dp(10)), lp(-1, dp(10)))
        actions.addView(actionButton("↻", "Recharger") { showHome(); preloadCounts() }, lp(dp(245), dp(80)))
        actions.addView(space(dp(10)), lp(-1, dp(10)))
        actions.addView(actionButton("⎋", "Quitter") { finish() }, lp(dp(245), dp(80)))
        row.addView(actions)
        p.addView(row, lp(-1, dp(330)))
        p.addView(text("Accès rapide  •  En direct  •  Films  •  Séries  •  Paramètres", 12, DIM, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(34)))
    }

    private fun preloadCounts() {
        if (server.isBlank()) return
        lifecycleScope.launch(Dispatchers.IO) { try { api("player_api.php", mapOf("action" to "get_live_streams")) } catch (_: Exception) {} }
    }

    private fun showLive() {
        val p = page("En direct")
        p.addView(navBar("En direct"), lp(-1, dp(46)))
        val search = input("Rechercher une chaîne…", "")
        p.addView(search, lp(-1, dp(46)))
        val columns = LinearLayout(this).apply { gravity = Gravity.TOP }
        val groupsPanel = rounded(0x44110A42.toInt(), 12f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val channelsPanel = rounded(0x44110A42.toInt(), 12f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val infoPanel = rounded(0x44110A42.toInt(), 12f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(12), dp(12), dp(12)) }
        columns.addView(groupsPanel, lp(dp(250), 0, 0f)); columns.addView(space(dp(10)), lp(dp(10), 1)); columns.addView(channelsPanel, lp(dp(390), 0, 0f)); columns.addView(space(dp(10)), lp(dp(10), 1)); columns.addView(infoPanel, lp(0, 0, 1f))
        p.addView(columns, lp(-1, 0, 1f))
        val status = text("Chargement des chaînes…", 13, SOFT, false).apply { gravity = Gravity.CENTER }
        groupsPanel.addView(status, lp(-1, dp(40)))
        lifecycleScope.launch {
            try {
                val catsRaw = withContext(Dispatchers.IO) { api("player_api.php", mapOf("action" to "get_live_categories")) }
                val streamsRaw = withContext(Dispatchers.IO) { api("player_api.php", mapOf("action" to "get_live_streams")) }
                val map = parseCategories(catsRaw)
                currentLiveItems = parseItems(streamsRaw, "live", map)
                renderLiveGroups(groupsPanel, channelsPanel, infoPanel, currentLiveItems)
                search.setOnEditorActionListener { _, _, _ -> renderLiveGroups(groupsPanel, channelsPanel, infoPanel, currentLiveItems, search.text.toString()); true }
            } catch (e: Exception) { status.text = "Impossible de charger les chaînes" }
        }
    }

    private fun renderLiveGroups(groupsPanel: LinearLayout, channelsPanel: LinearLayout, infoPanel: LinearLayout, source: List<TvItem>, query: String = "") {
        groupsPanel.removeAllViews(); channelsPanel.removeAllViews(); infoPanel.removeAllViews()
        val groups = listOf(Category("", "Toutes", source.size)) + source.groupBy { it.categoryId + "|" + it.categoryName }.map { (key, list) -> val parts = key.split("|", limit = 2); Category(parts[0], parts.getOrElse(1) { "Autres" }, list.size) }.sortedBy { it.name.lowercase(Locale.getDefault()) }
        groupsPanel.addView(text("GROUPES", 14, WHITE, true), lp(-1, dp(38)))
        groups.forEach { cat ->
            val b = listButton("${cat.name}\n${cat.count}") { selectedLiveGroup = cat.name; renderLiveChannels(channelsPanel, infoPanel, source, cat.name, query) }
            groupsPanel.addView(b, lp(-1, dp(62)))
        }
        renderLiveChannels(channelsPanel, infoPanel, source, selectedLiveGroup, query)
    }

    private fun renderLiveChannels(channelsPanel: LinearLayout, infoPanel: LinearLayout, source: List<TvItem>, group: String, query: String) {
        channelsPanel.removeAllViews(); infoPanel.removeAllViews()
        val filtered = source.filter { (group == "Toutes" || it.categoryName.equals(group, true)) && (query.isBlank() || it.name.contains(query, true)) }
        channelsPanel.addView(text("CHAÎNES  •  ${filtered.size}", 14, WHITE, true), lp(-1, dp(38)))
        val scroll = ScrollView(this)
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        filtered.take(250).forEach { item ->
            val b = channelButton(item) { currentLiveChannel = item; renderLiveInfo(infoPanel, item) }
            list.addView(b, lp(-1, dp(62)))
        }
        scroll.addView(list); channelsPanel.addView(scroll, lp(-1, 0, 1f))
        if (filtered.isNotEmpty()) { currentLiveChannel = filtered.first(); renderLiveInfo(infoPanel, filtered.first()) }
    }

    private fun renderLiveInfo(panel: LinearLayout, item: TvItem) {
        releasePreview(); panel.removeAllViews()
        panel.addView(text(item.name, 22, WHITE, true), lp(-1, dp(48)))
        val pv = PlayerView(this).apply { useController = false; setBackgroundColor(Color.BLACK) }
        panel.addView(pv, lp(-1, dp(235)))
        panel.addView(text("Programme en cours / EPG", 15, WHITE, true), lp(-1, dp(38)))
        val epg = text("Chargement…", 13, SOFT, false)
        panel.addView(epg, lp(-1, dp(70)))
        val buttons = LinearLayout(this)
        buttons.addView(tvButton("▶ LIRE") { play(item) }, lp(0, dp(54), 1f))
        buttons.addView(space(dp(10)), lp(dp(10), 1))
        buttons.addView(tvButton(if (favorites.contains(item.id)) "★ FAVORI" else "☆ FAVORI") { toggleFavorite(item); renderLiveInfo(panel, item) }, lp(0, dp(54), 1f))
        panel.addView(buttons, lp(-1, dp(54)))
        lifecycleScope.launch {
            try {
                val raw = withContext(Dispatchers.IO) { api("player_api.php", mapOf("action" to "get_short_epg", "stream_id" to item.id, "limit" to "4")) }
                epg.text = parseEpg(raw)
            } catch (_: Exception) { epg.text = "EPG indisponible pour cette chaîne" }
        }
        // Preview is opt-in after selecting the channel; it avoids starting many streams while navigating.
        pv.setOnClickListener { play(item) }
    }

    private fun parseEpg(raw: String): String {
        val arr = try { JSONObject(raw).optJSONArray("epg_listings") ?: JSONArray() } catch (_: Exception) { JSONArray() }
        if (arr.length() == 0) return "EPG indisponible pour cette chaîne"
        val out = StringBuilder()
        for (i in 0 until minOf(4, arr.length())) {
            val o = arr.optJSONObject(i) ?: continue
            val title = o.optString("title", "Programme")
            val start = o.optString("start", "")
            val end = o.optString("end", "")
            out.append(if (start.length >= 16) start.substring(11, 16) else "")
                .append("  ").append(title)
                .append(if (end.length >= 16) "  •  ${end.substring(11, 16)}" else "")
            if (i < minOf(4, arr.length()) - 1) out.append("\n")
        }
        return out.toString()
    }

    private fun showMovies() = showCatalog("Films", "movie")
    private fun showSeries() = showCatalog("Séries", "series")

    private fun showCatalog(title: String, type: String) {
        val p = page(title)
        p.addView(navBar(title), lp(-1, dp(46)))
        val columns = LinearLayout(this)
        val side = rounded(0x44110A42.toInt(), 12f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(8), dp(8), dp(8)) }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), 0, 0, 0) }
        columns.addView(side, lp(dp(255), 0, 0f)); columns.addView(content, lp(0, 0, 1f)); p.addView(columns, lp(-1, 0, 1f))
        lifecycleScope.launch {
            try {
                val catAction = if (type == "movie") "get_vod_categories" else "get_series_categories"
                val itemAction = if (type == "movie") "get_vod_streams" else "get_series"
                val cats = withContext(Dispatchers.IO) { parseCategoriesArray(api("player_api.php", mapOf("action" to catAction))) }
                val items = withContext(Dispatchers.IO) { parseItems(api("player_api.php", mapOf("action" to itemAction)), type, cats.associate { it.id to it.name }) }
                allItems = items.toMutableList()
                renderCatalogSide(side, content, items, type, "Toutes", cats)
            } catch (_: Exception) { content.addView(text("Impossible de charger $title", 16, WHITE, true), lp(-1, dp(60))) }
        }
    }

    private fun renderCatalogSide(side: LinearLayout, content: LinearLayout, items: List<TvItem>, type: String, selected: String, cats: List<Category>) {
        side.removeAllViews(); content.removeAllViews()
        side.addView(actionButton("‹", "Retour") { showHome() }, lp(-1, dp(48)))
        side.addView(actionButton("⌕", "Rechercher") { showCatalogSearch(type, items) }, lp(-1, dp(48)))
        val recent = history.count { id -> items.any { it.id == id } }
        side.addView(listButton("Récemment consulté\n$recent") { renderCatalogSide(side, content, items.filter { history.contains(it.id) }, type, "Récemment consulté", cats) }, lp(-1, dp(60)))
        side.addView(listButton("Tout\n${items.size}") { renderCatalogSide(side, content, items, type, "Toutes", cats) }, lp(-1, dp(60)))
        val fav = items.count { favorites.contains(it.id) }
        side.addView(listButton("Favori\n$fav") { renderCatalogSide(side, content, items.filter { favorites.contains(it.id) }, type, "Favori", cats) }, lp(-1, dp(60)))
        cats.sortedBy { it.name.lowercase(Locale.getDefault()) }.forEach { cat ->
            val count = items.count { it.categoryId == cat.id }
            side.addView(listButton("${cat.name}\n$count") { renderCatalogSide(side, content, items.filter { it.categoryId == cat.id }, type, cat.name, cats) }, lp(-1, dp(60)))
        }
        renderCatalogGrid(content, items, type, selected)
    }

    private fun renderCatalogGrid(content: LinearLayout, items: List<TvItem>, type: String, title: String) {
        content.removeAllViews()
        val head = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        head.addView(text("${title.uppercase()}  (${items.size})", 19, WHITE, true), lp(0, dp(46), 1f))
        head.addView(tvButton("Trier : note") { renderCatalogGrid(content, items.sortedByDescending { it.rating.toDoubleOrNull() ?: 0.0 }, type, title) }, lp(dp(150), dp(46)))
        content.addView(head)
        val scroll = ScrollView(this)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        var row: LinearLayout? = null
        items.take(120).forEachIndexed { index, item ->
            if (index % 6 == 0) { row = LinearLayout(this); grid.addView(row, lp(-1, dp(190))) }
            row!!.addView(posterCard(item, type), lp(0, dp(180), 1f))
            if (index % 6 != 5) row!!.addView(space(dp(9)), lp(dp(9), 1))
        }
        scroll.addView(grid); content.addView(scroll, lp(-1, 0, 1f))
    }

    private fun showCatalogSearch(type: String, items: List<TvItem>) {
        val input = input("Titre à rechercher", "")
        AlertDialog.Builder(this).setTitle("Rechercher").setView(input).setNegativeButton("Annuler", null).setPositiveButton("Rechercher") { _, _ ->
            val q = input.text.toString().trim()
            val found = items.filter { it.name.contains(q, true) }
            val p = page(if (type == "movie") "Films" else "Séries")
            renderCatalogGrid(p, found, type, "Résultats")
        }.show()
        input.requestFocus()
    }

    private fun posterCard(item: TvItem, type: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5), dp(5), dp(5), dp(5))
            background = focusBackground(false)
            isFocusable = true; isClickable = true
            setOnClickListener { if (type == "series") showSeriesDetail(item) else showMovieDetail(item) }
            setOnLongClickListener { toggleFavorite(item); true }
            setOnFocusChangeListener { v, h -> v.background = focusBackground(h) }
        }
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP; setBackgroundColor(0x55100A45) }
        if (item.logo.isNotBlank()) loader.enqueue(ImageRequest.Builder(this).data(item.logo).target(img).build())
        box.addView(img, lp(-1, dp(132)))
        box.addView(text(item.name, 12, WHITE, true).apply { maxLines = 2 }, lp(-1, dp(34)))
        if (item.rating.isNotBlank()) box.addView(text("★ ${item.rating}", 11, FOCUS, true), lp(-1, dp(18)))
        return box
    }

    private fun showMovieDetail(item: TvItem) {
        lifecycleScope.launch {
            val info = try { JSONObject(withContext(Dispatchers.IO) { api("player_api.php", mapOf("action" to "get_vod_info", "vod_id" to item.id)) }) } catch (_: Exception) { JSONObject() }
            val infoObj = info.optJSONObject("info") ?: JSONObject()
            val panel = detailPanel(item.name, item.logo, infoObj.optString("plot", "Synopsis indisponible"), "Film")
            panel.addView(tvButton("▶ LIRE") { play(item) }, lp(dp(220), dp(56)))
            panel.addView(space(dp(10)), lp(-1, dp(10)))
            panel.addView(tvButton(if (favorites.contains(item.id)) "★ FAVORI" else "☆ FAVORI") { toggleFavorite(item) }, lp(dp(220), dp(56)))
            showDetailDialog(item.name, panel)
        }
    }

    private fun showSeriesDetail(item: TvItem) {
        lifecycleScope.launch {
            val data = try { JSONObject(withContext(Dispatchers.IO) { api("player_api.php", mapOf("action" to "get_series_info", "series_id" to item.id)) }) } catch (_: Exception) { JSONObject() }
            val infoObj = data.optJSONObject("info") ?: JSONObject()
            val panel = detailPanel(item.name, item.logo, infoObj.optString("plot", "Synopsis indisponible"), "Série")
            val seasons = data.optJSONObject("episodes") ?: JSONObject()
            val seasonKeys = seasons.keys().asSequence().sortedBy { it.toIntOrNull() ?: 0 }.toList()
            panel.addView(text("SAISONS", 17, WHITE, true), lp(-1, dp(36)))
            val seasonRow = HorizontalScrollView(this@MainActivity)
            val sr = LinearLayout(this@MainActivity)
            seasonKeys.forEach { key -> sr.addView(tvButton("Saison $key") { showEpisodeDialog(item, seasons.optJSONArray(key) ?: JSONArray(), key) }, lp(dp(150), dp(52))) ; sr.addView(space(dp(8)), lp(dp(8), 1)) }
            seasonRow.addView(sr); panel.addView(seasonRow, lp(-1, dp(60)))
            panel.addView(tvButton(if (favorites.contains(item.id)) "★ FAVORI" else "☆ FAVORI") { toggleFavorite(item) }, lp(dp(220), dp(56)))
            showDetailDialog(item.name, panel)
        }
    }

    private fun showEpisodeDialog(series: TvItem, arr: JSONArray, season: String) {
        val list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val scroll = ScrollView(this)
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val id = o.optString("id")
            val ep = o.optInt("episode_num", i + 1)
            val title = o.optString("title", "Épisode $ep")
            val b = actionButton("▶", "S${season.padStart(2, '0')}E${ep.toString().padStart(2, '0')}  $title") {
                play(TvItem(id, title, o.optString("info", ""), "series_episode", o.optString("container_extension", "mp4")))
            }
            list.addView(b, lp(-1, dp(58)))
        }
        scroll.addView(list)
        AlertDialog.Builder(this).setTitle("Saison $season").setView(scroll).setPositiveButton("Fermer", null).show()
    }

    private fun detailPanel(title: String, image: String, synopsis: String, type: String): LinearLayout {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(24), dp(20), dp(24), dp(20)) }
        val top = LinearLayout(this)
        val img = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        if (image.isNotBlank()) loader.enqueue(ImageRequest.Builder(this).data(image).target(img).build())
        top.addView(img, lp(dp(190), dp(250)))
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(18), 0, 0, 0) }
        info.addView(text(title, 24, WHITE, true), lp(-1, dp(52)))
        info.addView(text(type, 14, FOCUS, true), lp(-1, dp(28)))
        info.addView(text(synopsis, 14, SOFT, false).apply { maxLines = 8 }, lp(-1, dp(150)))
        top.addView(info, lp(0, dp(250), 1f))
        panel.addView(top, lp(-1, dp(250)))
        return panel
    }

    private fun showDetailDialog(title: String, panel: View) {
        AlertDialog.Builder(this).setTitle(title).setView(panel).setPositiveButton("Fermer", null).show()
    }

    private fun showSettings() {
        val p = page("Paramètres", true)
        val grid = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val entries = listOf(
            "▣" to "Ajouter une liste de lecture" to { showPlaylists() },
            "♙" to "Contrôle parental" to { showParentalSettings() },
            "↕" to "Changer la liste de lecture" to { showPlaylists() },
            "文" to "Changer la langue" to { choice("Langue", "language", arrayOf("Français", "English", "Español", "Italiano")) },
            "▦" to "Changer la disposition" to { choice("Disposition", "layout", arrayOf("Classique", "Compacte", "Grande TV")) },
            "◉" to "Masquer les catégories en direct" to { toggle("Catégories Live", "hide_live") },
            "◉" to "Masquer les catégories VOD" to { toggle("Catégories VOD", "hide_vod") },
            "◉" to "Masquer les catégories Séries" to { toggle("Catégories Séries", "hide_series") },
            "▣" to "Effacer historique des chaînes" to { clearHistory("chaînes") },
            "▣" to "Effacer historique des films" to { clearHistory("films") },
            "▣" to "Effacer historique des séries" to { clearHistory("séries") },
            "A↕" to "Tri des chaînes en direct" to { choice("Tri des chaînes", "channel_sort", arrayOf("A → Z", "Z → A", "Ajoutées récemment")) },
            "TV" to "Format de diffusion TV en direct" to { choice("Format TV", "live_format", arrayOf("Automatique", "16:9", "4:3")) },
            "▶" to "Lecteur externe" to { choice("Lecteur", "player", arrayOf("TvMax", "Lecteur externe")) },
            "↻" to "Mise à jour automatique" to { toggle("Mise à jour automatique", "auto_update", true) },
            "◷" to "Format de l'heure" to { choice("Heure", "time_format", arrayOf("24 heures", "12 heures")) },
            "▤" to "Paramètres des sous-titres" to { choice("Sous-titres", "subtitle", arrayOf("Désactivés", "Français", "English", "Automatique")) },
            "▣" to "Type d'appareil" to { choice("Appareil", "device_type", arrayOf("Android TV", "Téléphone / tablette")) },
            "♙" to "Contrôle parental activé / désactivé" to { toggleParental() },
            "↓" to "Mettre à jour maintenant" to { updateDialog() }
        )
        for (r in 0 until 5) {
            val row = LinearLayout(this)
            for (c in 0 until 4) {
                val idx = r * 4 + c
                if (idx < entries.size) {
                    val e = entries[idx]
                    row.addView(settingsButton(e.first.first, e.first.second, e.second), lp(0, dp(72), 1f))
                    if (c < 3) row.addView(space(dp(10)), lp(dp(10), 1))
                }
            }
            grid.addView(row, lp(-1, dp(72))); if (r < 4) grid.addView(space(dp(9)), lp(-1, dp(9)))
        }
        p.addView(grid, lp(-1, dp(396)))
        p.addView(text("Playlist : $playlistName", 14, SOFT, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(28)))
        p.addView(text("TvMax  •  Android TV  •  V8.0", 12, DIM, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(26)))
    }

    private fun showPlaylists() {
        val p = page("Listes de lecture", true)
        val panel = rounded(0x99120B50.toInt(), 22f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(28), dp(20), dp(28), dp(20)) }
        panel.addView(text("Liste actuelle", 18, WHITE, true), lp(-1, dp(38)))
        panel.addView(text(playlistName, 15, SOFT, false), lp(-1, dp(36)))
        panel.addView(tvButton("AJOUTER / MODIFIER LA LISTE") { showLogin() }, lp(dp(350), dp(58)))
        p.addView(panel, lp(dp(700), dp(200)))
    }

    private fun showAccount() {
        val p = page("Compte", true)
        val panel = rounded(0x99120B50.toInt(), 22f).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(30), dp(22), dp(30), dp(22)) }
        panel.addView(text(username, 22, WHITE, true), lp(-1, dp(42)))
        panel.addView(text(server, 13, SOFT, false), lp(-1, dp(36)))
        panel.addView(text("Playlist : $playlistName", 14, DIM, false), lp(-1, dp(36)))
        panel.addView(tvButton("SE DÉCONNECTER") { prefs.edit().clear().apply(); showLogin() }, lp(dp(280), dp(58)))
        p.addView(panel, lp(dp(760), dp(260)))
    }

    private fun choice(title: String, key: String, options: Array<String>) {
        val current = prefs.getString(key, options.first()) ?: options.first()
        AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(options, options.indexOf(current).coerceAtLeast(0)) { d, w -> prefs.edit().putString(key, options[w]).apply(); d.dismiss(); toast("${options[w]} sélectionné") }.setNegativeButton("Annuler", null).show()
    }

    private fun toggle(title: String, key: String, default: Boolean = false) {
        val current = prefs.getBoolean(key, default)
        AlertDialog.Builder(this).setTitle(title).setSingleChoiceItems(arrayOf("Activé", "Désactivé"), if (current) 0 else 1) { d, w -> prefs.edit().putBoolean(key, w == 0).apply(); d.dismiss() }.setNegativeButton("Annuler", null).show()
    }

    private fun clearHistory(kind: String) {
        AlertDialog.Builder(this).setTitle("Effacer l'historique").setMessage("Effacer l'historique des $kind ?").setNegativeButton("Annuler", null).setPositiveButton("Effacer") { _, _ -> history.clear(); persist(); toast("Historique effacé") }.show()
    }

    private fun showParentalSettings() {
        val input = EditText(this).apply { hint = "PIN à 4 chiffres"; inputType = 2; isSingleLine = true }
        AlertDialog.Builder(this).setTitle("Contrôle parental").setMessage("Définissez un PIN à 4 chiffres.").setView(input).setNegativeButton("Annuler", null).setPositiveButton("Enregistrer") { _, _ -> if (input.text.length == 4) { prefs.edit().putString("parental_pin", input.text.toString()).putBoolean("parental_enabled", true).apply(); toast("Contrôle parental activé") } else toast("PIN invalide") }.show()
    }

    private fun toggleParental() {
        val enabled = prefs.getBoolean("parental_enabled", false)
        if (!enabled) showParentalSettings() else AlertDialog.Builder(this).setTitle("Contrôle parental").setMessage("Désactiver le contrôle parental ?").setNegativeButton("Annuler", null).setPositiveButton("Désactiver") { _, _ -> prefs.edit().putBoolean("parental_enabled", false).apply() }.show()
    }

    private fun updateDialog() {
        AlertDialog.Builder(this).setTitle("Mise à jour TvMax").setMessage("Version installée : V8.0\n\nLa vérification automatique pourra être connectée à un serveur de mise à jour dans une prochaine étape.").setPositiveButton("OK", null).show()
    }

    private fun parseCategories(raw: String): Map<String, String> = parseCategoriesArray(raw).associate { it.id to it.name }

    private fun parseCategoriesArray(raw: String): List<Category> {
        val arr = JSONArray(raw)
        return buildList { for (i in 0 until arr.length()) { val o = arr.optJSONObject(i) ?: continue; add(Category(o.optString("category_id"), o.optString("category_name", "Autres"), 0)) } }
    }

    private fun parseItems(raw: String, type: String, cats: Map<String, String>): List<TvItem> {
        val arr = JSONArray(raw)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("stream_id", o.optString("series_id", i.toString()))
                val catId = o.optString("category_id", "")
                val catName = cats[catId] ?: o.optString("group-title", o.optString("group_title", "Autres"))
                add(TvItem(id, o.optString("name", "Sans titre"), o.optString("stream_icon", o.optString("cover", "")), type, o.optString("container_extension", "mp4"), catId, catName, o.optString("rating", "")))
            }
        }
    }

    private fun play(item: TvItem) {
        val path: String
        val ext: String
        val id = item.id
        when (item.type) {
            "live" -> { path = "live"; ext = "ts" }
            "movie" -> { path = "movie"; ext = item.extension.ifBlank { "mp4" } }
            "series_episode" -> { path = "series"; ext = item.extension.ifBlank { "mp4" } }
            else -> { path = "movie"; ext = item.extension.ifBlank { "mp4" } }
        }
        val url = "$server/$path/${Uri.encode(username)}/${Uri.encode(password)}/$id.$ext"
        history.remove(id); history.add(0, id); history = history.take(50).toMutableList(); persist()
        releasePlayers()
        player = ExoPlayer.Builder(this).build()
        val pv = PlayerView(this).apply { player = this@MainActivity.player; useController = true }
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(pv); d.setOnDismissListener { player?.release(); player = null }; d.show()
        player?.setMediaItem(MediaItem.fromUri(url)); player?.prepare(); player?.playWhenReady = true
    }

    private fun releasePreview() { previewPlayer?.release(); previewPlayer = null }
    private fun releasePlayers() { releasePreview(); player?.release(); player = null }
    private fun toggleFavorite(item: TvItem) { if (favorites.contains(item.id)) favorites.remove(item.id) else favorites.add(item.id); persist(); toast(if (favorites.contains(item.id)) "Ajouté aux favoris" else "Retiré des favoris") }
    private fun persist() { prefs.edit().putStringSet("favorites", favorites).putStringSet("history", history.toSet()).apply() }
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private fun heroButton(icon: String, label: String, click: () -> Unit): View = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = focusBackground(false); isFocusable = true; setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) }; addView(text(icon, 58, WHITE, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(100))); addView(text(label, 22, WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(48))) }
    private fun tileButton(icon: String, label: String, click: () -> Unit): View = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; background = focusBackground(false); isFocusable = true; setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) }; addView(text(icon, 34, WHITE, false).apply { gravity = Gravity.CENTER }, lp(-1, dp(62))); addView(text(label, 16, WHITE, true).apply { gravity = Gravity.CENTER }, lp(-1, dp(42))) }
    private fun actionButton(icon: String, label: String, click: () -> Unit): View = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; background = focusBackground(false); isFocusable = true; isClickable = true; setPadding(dp(12), 0, dp(12), 0); setOnClickListener { click() }; setOnFocusChangeListener { v, h -> v.background = focusBackground(h) }; addView(text(icon, 26, WHITE, false).apply { gravity = Gravity.CENTER }, lp(dp(44), dp(62))); addView(text(label, 14, WHITE, true), lp(0, dp(62), 1f)) }
    private fun settingsButton(icon: String, label: String, click: () -> Unit): View = actionButton(icon, label, click)
    private fun channelButton(item: TvItem, click: () -> Unit): View { val b = actionButton(if (favorites.contains(item.id)) "★" else "○", item.name, click); return b }
    private fun listButton(label: String, click: () -> Unit): View = actionButton("", label, click)
    private fun tvButton(label: String, click: () -> Unit): View = actionButton("", label, click)
    private fun focusBackground(focused: Boolean): GradientDrawable = GradientDrawable().apply { cornerRadius = dp(10).toFloat(); setColor(if (focused) CARD else CARD2); setStroke(if (focused) dp(3) else dp(1), if (focused) FOCUS else 0x66FFFFFF) }
    private fun tvGradient() = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(BG_TOP, BG_MID, BG_BOTTOM))
    private fun rounded(color: Int, radius: Float) = LinearLayout(this).apply { background = GradientDrawable().apply { setColor(color); cornerRadius = dp(radius.toInt()).toFloat() } }
    private fun input(hint: String, value: String) = EditText(this).apply { this.hint = hint; setText(value); setTextColor(WHITE); setHintTextColor(DIM); textSize = 15f; isSingleLine = true; setPadding(dp(14), 0, dp(14), 0); background = GradientDrawable().apply { setColor(0xAA0D0A36.toInt()); cornerRadius = dp(9).toFloat(); setStroke(dp(1), 0x66FFFFFF) } }
    private fun text(s: String, size: Int, color: Int, bold: Boolean) = TextView(this).apply { text = s; textSize = size.toFloat(); setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD); gravity = Gravity.CENTER_VERTICAL; includeFontPadding = true }
    private fun space(v: Int) = Space(this)
    private fun lp(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
}
