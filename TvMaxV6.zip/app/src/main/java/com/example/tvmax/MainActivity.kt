package com.example.tvmax

import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.ImageLoader
import coil.request.ImageRequest
import coil.target.ImageViewTarget
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private const val BG = 0xFF070A10.toInt()
private const val PANEL = 0xFF101620.toInt()
private const val PANEL2 = 0xFF151D29.toInt()
private const val PURPLE = 0xFF7C5CFC.toInt()
private const val WHITE = 0xFFF7F8FA.toInt()
private const val MUTED = 0xFF9BA5B5.toInt()

data class MediaItemX(
    val id: String,
    val name: String,
    val categoryId: String,
    val logo: String,
    val type: String,
    val extension: String = ""
)

class MainActivity : AppCompatActivity() {
    private lateinit var root: FrameLayout
    private lateinit var main: LinearLayout
    private lateinit var nav: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private lateinit var search: EditText

    private var server = ""
    private var username = ""
    private var password = ""
    private var active = "home"
    private var all = mutableListOf<MediaItemX>()
    private var favorites = mutableSetOf<String>()
    private var history = mutableListOf<String>()
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val p = getSharedPreferences("tvmax6", Context.MODE_PRIVATE)
        server = p.getString("server", "") ?: ""
        username = p.getString("user", "") ?: ""
        password = p.getString("pass", "") ?: ""
        favorites = (p.getStringSet("favorites", emptySet()) ?: emptySet()).toMutableSet()
        history = (p.getStringSet("history", emptySet()) ?: emptySet()).toMutableList()
        if (server.isBlank()) showLogin() else showDashboard()
    }

    private fun showLogin() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(70, 55, 70, 55)
            setBackgroundColor(BG)
        }
        box.addView(tv("TvMax", 42, WHITE, true), lp(-1, 60))
        box.addView(tv("Votre télévision. Votre interface.", 20, MUTED, false), lp(-1, 50))
        val s = edit("URL du serveur", server)
        val u = edit("Nom d'utilisateur", username)
        val pw = edit("Mot de passe", password)
        pw.inputType = 0x81
        box.addView(s, lp(-1, 58))
        box.addView(u, lp(-1, 58))
        box.addView(pw, lp(-1, 58))
        val b = Button(this).apply {
            text = "SE CONNECTER"
            isFocusable = true
            setOnClickListener {
                server = s.text.toString().trim().removeSuffix("/")
                username = u.text.toString().trim()
                password = pw.text.toString().trim()
                connect()
            }
        }
        box.addView(b, lp(-1, 62))
        val st = tv("Connexion sécurisée à votre service IPTV autorisé.", 14, MUTED, false)
        box.addView(st, lp(-1, 55))
        setContentView(box)
        b.requestFocus()
    }

    private fun connect() {
        lifecycleScope.launch {
            try {
                val raw = withContext(Dispatchers.IO) {
                    URL("$server/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}").readText()
                }
                if (!JSONObject(raw).has("user_info")) throw Exception("Identifiants incorrects")
                getSharedPreferences("tvmax6", 0).edit()
                    .putString("server", server).putString("user", username).putString("pass", password).apply()
                showDashboard()
            } catch (e: Exception) {
                Toast.makeText(this@MainActivity, "Connexion impossible : ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showDashboard() {
        root = FrameLayout(this).apply { setBackgroundColor(BG) }
        main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        nav = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 26, 14, 20)
            setBackgroundColor(0xFF0B0F17.toInt())
        }
        main.addView(nav, LinearLayout.LayoutParams(92, -1))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 22, 28, 18)
        }
        val scroll = ScrollView(this).apply { addView(content) }
        main.addView(scroll, LinearLayout.LayoutParams(0, -1, 1f))
        root.addView(main)
        setContentView(root)
        buildNav()
        showHome()
    }

    private fun buildNav() {
        nav.removeAllViews()
        nav.addView(tv("TV", 26, PURPLE, true).apply { gravity = Gravity.CENTER }, lp(-1, 55))
        nav.addView(space(18), lp(-1, 18))
        val items = listOf(
            "home" to "⌂",
            "live" to "TV",
            "movies" to "FILM",
            "series" to "S",
            "fav" to "★",
            "search" to "⌕",
            "settings" to "⚙"
        )
        items.forEach { (id, icon) ->
            val b = TextView(this).apply {
                text = icon
                textSize = 22f
                gravity = Gravity.CENTER
                setTextColor(if (active == id) WHITE else MUTED)
                isFocusable = true
                setPadding(4, 12, 4, 12)
                setBackgroundColor(if (active == id) 0xFF20283A.toInt() else Color.TRANSPARENT)
                setOnClickListener { active = id; buildNav(); when(id) {
                    "home" -> showHome()
                    "live" -> load("live")
                    "movies" -> load("movie")
                    "series" -> load("series")
                    "fav" -> showFavorites()
                    "search" -> showSearch()
                    "settings" -> showSettings()
                }}
            }
            nav.addView(b, lp(-1, 62))
            nav.addView(space(7), lp(-1, 7))
        }
    }

    private fun showHome() {
        content.removeAllViews()
        val top = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
        top.addView(tv("Accueil", 30, WHITE, true), LinearLayout.LayoutParams(0, 55, 1f))
        top.addView(tv("TVMAX V6", 13, MUTED, true).apply { gravity = Gravity.CENTER }, lp(120, 50))
        content.addView(top)
        val hero = GradientCard(0xFF171A35.toInt())
        hero.addView(tv("Votre télévision,\nréinventée.", 30, WHITE, true), lp(-1, 90))
        hero.addView(tv("Accédez rapidement à vos chaînes, films et séries.", 16, MUTED, false), lp(-1, 45))
        val heroBtn = Button(this).apply {
            text = "▶  REGARDER"
            isFocusable = true
            setOnClickListener { active = "live"; buildNav(); load("live") }
        }
        hero.addView(heroBtn, lp(180, 56))
        content.addView(hero, lp(-1, 210))
        sectionTitle("Accès rapide")
        val quick = LinearLayout(this)
        quick.addView(bigButton("LIVE TV", "Chaînes en direct") { active="live"; buildNav(); load("live") })
        quick.addView(bigButton("FILMS", "Votre bibliothèque") { active="movies"; buildNav(); load("movie") })
        quick.addView(bigButton("SÉRIES", "Saisons & épisodes") { active="series"; buildNav(); load("series") })
        content.addView(quick, lp(-1, 130))
        if (history.isNotEmpty()) {
            sectionTitle("Reprendre")
            content.addView(horizontalHistory())
        }
        sectionTitle("Vos favoris")
        content.addView(horizontalFavorites())
    }

    private fun sectionTitle(s: String) {
        content.addView(tv(s, 21, WHITE, true), lp(-1, 48))
    }

    private fun horizontalFavorites(): HorizontalScrollView {
        val row = LinearLayout(this)
        favorites.take(8).forEach { id ->
            val item = all.firstOrNull { it.id == id }
            if (item != null) row.addView(mediaCard(item), lp(190, 220))
        }
        return HorizontalScrollView(this).apply { addView(row) }
    }

    private fun horizontalHistory(): HorizontalScrollView {
        val row = LinearLayout(this)
        history.take(8).forEach { id ->
            val item = all.firstOrNull { it.id == id }
            if (item != null) row.addView(mediaCard(item), lp(190, 220))
        }
        return HorizontalScrollView(this).apply { addView(row) }
    }

    private fun load(type: String) {
        content.removeAllViews()
        content.addView(tv(if (type=="live") "Live TV" else if (type=="movie") "Films" else "Séries", 30, WHITE, true), lp(-1, 55))
        search = edit("Rechercher…", "")
        content.addView(search, lp(-1, 54))
        status = tv("Chargement…", 14, MUTED, false)
        content.addView(status, lp(-1, 42))
        lifecycleScope.launch {
            try {
                val endpoint = when(type) {
                    "movie" -> "get_vod_streams"
                    "series" -> "get_series"
                    else -> "get_live_streams"
                }
                val raw = withContext(Dispatchers.IO) {
                    URL("$server/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=$endpoint").readText()
                }
                all = parse(raw, type).toMutableList()
                status.text = "${all.size} contenus disponibles"
                renderGrid(all)
            } catch (e: Exception) {
                status.text = "Erreur de chargement"
            }
        }
    }

    private fun renderGrid(list: List<MediaItemX>) {
        val grid = GridLayout(this).apply { columnCount = 5 }
        list.take(500).forEach { item ->
            grid.addView(mediaCard(item), GridLayout.LayoutParams().apply {
                width = 0; height = 230
                columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f)
                setMargins(7,7,7,7)
            })
        }
        content.addView(grid)
    }

    private fun mediaCard(item: MediaItemX): View {
        val card = CardView(this).apply {
            radius = 16f
            cardElevation = 7f
            setCardBackgroundColor(PANEL)
            isFocusable = true
            setOnClickListener { play(item) }
            setOnLongClickListener {
                if (favorites.contains(item.id)) favorites.remove(item.id) else favorites.add(item.id)
                persist()
                true
            }
        }
        val box = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        val image = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            setBackgroundColor(PANEL2)
        }
        if (item.logo.isNotBlank()) {
            ImageLoader(this).enqueue(
                ImageRequest.Builder(this).data(item.logo).target(image).build()
            )
        }
        box.addView(image, lp(-1, 155))
        val name = tv(item.name, 14, WHITE, true).apply { maxLines=2 }
        box.addView(name, lp(-1, 48))
        val line = LinearLayout(this)
        line.addView(tv(if (favorites.contains(item.id)) "★" else "☆", 20, PURPLE, false),
            LinearLayout.LayoutParams(40, 38))
        line.addView(tv(if(item.type=="live") "DIRECT" else item.type.uppercase(), 11, MUTED, true),
            LinearLayout.LayoutParams(0, 38, 1f))
        box.addView(line)
        card.addView(box)
        return card
    }

    private fun parse(raw: String, type: String): List<MediaItemX> {
        val arr = JSONArray(raw)
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val id = o.optString("stream_id", o.optString("series_id", i.toString()))
                val name = o.optString("name", "Sans titre")
                val cat = o.optString("category_id", "")
                val logo = o.optString("stream_icon", o.optString("cover", ""))
                val ext = o.optString("container_extension", "mp4")
                add(MediaItemX(id, name, cat, logo, type, ext))
            }
        }
    }

    private fun play(item: MediaItemX) {
        val path = when(item.type) {
            "movie" -> "movie"
            else -> "live"
        }
        val ext = if (item.type == "live") "ts" else item.extension.ifBlank { "mp4" }
        val url = "$server/$path/${Uri.encode(username)}/${Uri.encode(password)}/${item.id}.$ext"
        history.remove(item.id); history.add(0, item.id); history = history.take(30).toMutableList(); persist()
        player?.release()
        player = ExoPlayer.Builder(this).build()
        val pv = PlayerView(this).apply { player = this@MainActivity.player; useController = true }
        val d = Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen)
        d.setContentView(pv)
        d.setOnDismissListener { player?.release(); player=null }
        d.show()
        player?.setMediaItem(MediaItem.fromUri(url))
        player?.prepare()
        player?.playWhenReady = true
    }

    private fun showFavorites() {
        content.removeAllViews()
        content.addView(tv("Mes favoris", 30, WHITE, true), lp(-1, 55))
        val list = all.filter { favorites.contains(it.id) }
        if (list.isEmpty()) content.addView(tv("Aucun favori. Maintiens OK sur un contenu pour l'ajouter.", 16, MUTED, false), lp(-1, 50))
        else renderGrid(list)
    }

    private fun showSearch() {
        content.removeAllViews()
        content.addView(tv("Recherche", 30, WHITE, true), lp(-1, 55))
        val q = edit("Tapez le nom d'une chaîne, d'un film ou d'une série", "")
        content.addView(q, lp(-1, 58))
        q.requestFocus()
        q.setOnEditorActionListener { _,_,_ ->
            val term=q.text.toString()
            content.removeViews(2, content.childCount-2)
            renderGrid(all.filter { it.name.contains(term, true) })
            true
        }
        if (all.isNotEmpty()) renderGrid(all)
    }

    private fun showSettings() {
        content.removeAllViews()
        content.addView(tv("Paramètres", 30, WHITE, true), lp(-1, 55))
        val panel = GradientCard(PANEL)
        panel.addView(tv("Compte", 19, WHITE, true), lp(-1, 45))
        panel.addView(tv("$username\n$server", 14, MUTED, false), lp(-1, 65))
        val clear = Button(this).apply {
            text = "EFFACER L'HISTORIQUE"
            isFocusable = true
            setOnClickListener { history.clear(); persist(); Toast.makeText(this@MainActivity,"Historique effacé",Toast.LENGTH_SHORT).show() }
        }
        panel.addView(clear, lp(-1, 55))
        val logout = Button(this).apply {
            text = "SE DÉCONNECTER"
            isFocusable = true
            setOnClickListener { getSharedPreferences("tvmax6",0).edit().clear().apply(); showLogin() }
        }
        panel.addView(logout, lp(-1, 55))
        content.addView(panel, lp(-1, 230))
    }

    private fun persist() {
        getSharedPreferences("tvmax6",0).edit()
            .putStringSet("favorites", favorites)
            .putStringSet("history", history.toSet()).apply()
    }

    private fun GradientCard(color: Int): LinearLayout {
        return LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL
            setPadding(22,18,22,18)
            val gd=GradientDrawable().apply { setColor(color); cornerRadius=22f }
            background=gd
        }
    }

    private fun bigButton(title:String, sub:String, click:()->Unit): View {
        val c=CardView(this).apply {
            radius=18f; cardElevation=6f; setCardBackgroundColor(PANEL2); isFocusable=true
            setOnClickListener{click()}
        }
        val b=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(20,15,20,15)}
        b.addView(tv(title,19,WHITE,true),lp(-1,42))
        b.addView(tv(sub,12,MUTED,false),lp(-1,34))
        c.addView(b); return c
    }

    private fun edit(h:String,v:String)=EditText(this).apply{
        hint=h; setText(v); setTextColor(WHITE); setHintTextColor(MUTED); singleLine=true
        setPadding(16,0,16,0); setBackgroundColor(PANEL)
    }

    private fun tv(t:String,s:Int,c:Int,b:Boolean)=TextView(this).apply{
        text=t;textSize=s.toFloat();setTextColor(c);gravity=Gravity.CENTER_VERTICAL
        setPadding(6,0,6,0); if(b) setTypeface(typeface,android.graphics.Typeface.BOLD)
    }

    private fun space(h:Int)=Space(this)

    private fun lp(w:Int,h:Int)=LinearLayout.LayoutParams(w,h)
}
