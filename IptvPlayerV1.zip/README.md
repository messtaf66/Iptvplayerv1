# IPTV Player V1

Prototype Android/Android TV en Kotlin + Jetpack Compose + Media3.

## Fonctionnalités
- Import d'une playlist M3U par URL
- Parsing EXTINF
- Catégories via group-title
- Recherche
- Favoris
- Lecture vidéo via Media3/ExoPlayer
- Support des URLs de flux compatibles avec Media3

## Ouvrir le projet
1. Installer Android Studio.
2. Ouvrir le dossier `IptvPlayerV1`.
3. Laisser Gradle télécharger les dépendances.
4. Lancer sur un appareil Android ou un émulateur.

Utilise uniquement des flux et contenus auxquels tu as légalement accès.
