# TvMax V3.1

Première grosse refonte de l'interface TvMax pour Android TV / NVIDIA Shield.

Inclus :
- Accueil
- Live TV / Films / Séries
- Recherche
- Favoris persistants
- Logos/affiches via les URLs fournies par Xtream
- Catégories
- Écran de lecture Media3
- EPG court pour le direct
- Connexion Xtream Codes mémorisée
- Version 3.1 / versionCode 3

Important : cette application est un lecteur. Utilise uniquement des flux et identifiants auxquels tu as légalement accès.
