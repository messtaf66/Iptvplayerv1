# TvMax V9

Version 9 rebuild based on the TV workflow requested by the user: Android TV dashboard, Xtream categories for Live/VOD/Series, favorites/history, EPG, film/series details, seasons/episodes, settings, and remote-friendly focus.

This project uses its own implementation and branding. It does not bundle proprietary IBO Player Pro code or assets.
