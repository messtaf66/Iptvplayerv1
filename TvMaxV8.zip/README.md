TvMax V8 - premium Android TV IPTV UI. Built for authorized Xtream/IPTV services.

V8 adds dashboard navigation, Live TV groups/EPG panel, VOD and Series catalogs, series seasons/episodes, favorites, history, search and functional settings.
