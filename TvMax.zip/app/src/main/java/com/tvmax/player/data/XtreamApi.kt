package com.tvmax.player.data

import com.tvmax.player.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

class XtreamApi(private val c: XtreamConfig) {
    private fun base():String = c.host.trimEnd('/') + "/player_api.php"
    private suspend fun get(action:String):JSONArray? = withContext(Dispatchers.IO) {
        val u = base()+"?username="+enc(c.username)+"&password="+enc(c.password)+"&action="+enc(action)
        val con=URL(u).openConnection() as HttpURLConnection; con.connectTimeout=15000; con.readTimeout=30000
        try { if(con.responseCode !in 200..299) return@withContext null; JSONArray(con.inputStream.bufferedReader().use{it.readText()}) } finally { con.disconnect() }
    }
    private fun enc(s:String)=URLEncoder.encode(s,"UTF-8")
    suspend fun testConnection(): Boolean = withContext(Dispatchers.IO) {
        val u = base()+"?username="+enc(c.username)+"&password="+enc(c.password)
        val con = URL(u).openConnection() as HttpURLConnection
        con.connectTimeout = 10000; con.readTimeout = 15000
        try {
            if (con.responseCode !in 200..299) return@withContext false
            val body = con.inputStream.bufferedReader().use { it.readText() }
            body.contains("user_info") || body.contains("server_info") || body.contains("auth")
        } catch (_: Exception) { false } finally { con.disconnect() }
    }
    suspend fun liveCategories()=categories(get("get_live_categories"))
    suspend fun vodCategories()=categories(get("get_vod_categories"))
    suspend fun seriesCategories()=categories(get("get_series_categories"))
    suspend fun live(category:String?=null)=streams(get(if(category==null) "get_live_streams" else "get_live_streams&category_id=$category"))
    suspend fun vod(category:String?=null)=streams(get(if(category==null) "get_vod_streams" else "get_vod_streams&category_id=$category"))
    suspend fun series(category:String?=null)=streams(get(if(category==null) "get_series" else "get_series&category_id=$category"))
    private fun categories(a:JSONArray?):List<Category> = if(a==null) emptyList() else (0 until a.length()).map{ val o=a.getJSONObject(it); Category(o.optString("category_id"),o.optString("category_name")) }
    private fun streams(a:JSONArray?):List<StreamItem> = if(a==null) emptyList() else (0 until a.length()).map{ val o=a.getJSONObject(it); StreamItem(o.optString("stream_id",o.optString("series_id")),o.optString("name"),o.optString("category_id"),o.optString("stream_icon").ifBlank{null},o.optString("rating").ifBlank{null},o.optString("plot").ifBlank{null}) }
}
