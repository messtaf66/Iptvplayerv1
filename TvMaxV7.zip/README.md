# TvMax V7

Version 7 focuses on a true Android TV dashboard inspired by the supplied reference screens: blue/violet gradient background, magenta TV tiles, large remote-friendly focus states, dedicated settings grid, account and playlist screens.

Xtream Codes connection and authorized IPTV playback are retained from the previous build.
