package com.tvmax.player.ui

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*

class SettingsActivity:Activity(){
 override fun onCreate(b:Bundle?){super.onCreate(b)
  val l=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(50,30,50,30);setBackgroundColor(Color.rgb(9,11,34))}
  val h=TextView(this).apply{text="Paramètres";textSize=34f;setTextColor(Color.WHITE);gravity=Gravity.CENTER}
  l.addView(h,LinearLayout.LayoutParams(-1,80))
  add(l,"Ajouter une playlist"){startActivity(Intent(this,PlaylistActivity::class.java))}
  add(l,"Changer la playlist"){startActivity(Intent(this,PlaylistActivity::class.java))}
  add(l,"Contrôle parental"){}
  add(l,"Langue"){}
  add(l,"Disposition"){}
  add(l,"Masquer les catégories"){}
  add(l,"Effacer l’historique"){}
  add(l,"Format de l'heure"){}
  add(l,"Sous-titres"){}
  add(l,"Lecteur externe"){}
  setContentView(ScrollView(this).apply{addView(l)})
 }
 private fun add(l:LinearLayout,t:String,click:()->Unit){val x=Button(this).apply{text=t;textSize=18f;isFocusable=true;setTextColor(Color.WHITE);background=getDrawable(com.tvmax.player.R.drawable.focus_bg);setOnClickListener{click()}};l.addView(x,LinearLayout.LayoutParams(-1,64).apply{setMargins(0,5,0,5)})}
}
