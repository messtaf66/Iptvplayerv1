package com.example.tvmax

import android.content.Context
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

private val Bg = Color(0xFF08090D)
private val Panel = Color(0xFF11131A)
private val Accent = Color(0xFF7C4DFF)
private val TextMain = Color(0xFFF5F5F7)
private val TextDim = Color(0xFF9EA3B0)

data class XtreamItem(
    val id: String,
    val name: String,
    val categoryId: String = "",
    val icon: String? = null,
    val streamUrl: String = "",
    val isSeries: Boolean = false
)

data class EpgItem(val title: String, val start: String, val end: String)

class IptvViewModel : ViewModel() {
    var server by mutableStateOf("")
    var username by mutableStateOf("")
    var password by mutableStateOf("")
    var connected by mutableStateOf(false)
    var loading by mutableStateOf(false)
    var message by mutableStateOf("Connecte ton compte Xtream Codes.")
    var section by mutableStateOf("Accueil")
    var categories by mutableStateOf<List<Pair<String, String>>>(emptyList())
    var items by mutableStateOf<List<XtreamItem>>(emptyList())
    var favorites by mutableStateOf<Set<String>>(emptySet())
    var selectedItem by mutableStateOf<XtreamItem?>(null)
    var seriesEpisodes by mutableStateOf<List<XtreamItem>>(emptyList())
    var epg by mutableStateOf<List<EpgItem>>(emptyList())

    private fun base() = server.trim().removeSuffix("/")

    private suspend fun getJson(path: String): String = withContext(Dispatchers.IO) {
        val c = (URL(path).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 25000
            requestMethod = "GET"
        }
        try {
            c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    private fun api(action: String) =
        "${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=$action"

    fun connect(scope: kotlinx.coroutines.CoroutineScope) {
        if (server.isBlank() || username.isBlank() || password.isBlank()) {
            message = "Renseigne les 3 champs."
            return
        }
        scope.launch {
            loading = true
            try {
                val obj = JSONObject(getJson("${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}"))
                val info = obj.optJSONObject("user_info")
                if (info?.optString("auth") == "1") {
                    connected = true
                    message = "Connexion réussie"
                    loadSection(scope, "Live TV")
                } else {
                    connected = false
                    message = "Identifiants refusés."
                }
            } catch (e: Exception) {
                connected = false
                message = "Erreur : ${e.message ?: "serveur inaccessible"}"
            } finally { loading = false }
        }
    }

    fun loadSection(scope: kotlinx.coroutines.CoroutineScope, target: String) {
        if (!connected) return
        section = target
        if (target == "Accueil") return
        scope.launch {
            loading = true
            try {
                when (target) {
                    "Live TV" -> {
                        categories = parseCategories(getJson(api("get_live_categories")))
                        items = parseLive(getJson(api("get_live_streams")))
                    }
                    "Films" -> {
                        categories = parseCategories(getJson(api("get_vod_categories")))
                        items = parseVod(getJson(api("get_vod_streams")))
                    }
                    "Séries" -> {
                        categories = parseCategories(getJson(api("get_series_categories")))
                        items = parseSeries(getJson(api("get_series")))
                    }
                }
                message = "${items.size} éléments chargés"
            } catch (e: Exception) {
                message = "Erreur de chargement"
            } finally { loading = false }
        }
    }

    private fun parseCategories(raw: String): List<Pair<String, String>> {
        val a = JSONArray(raw)
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(o.optString("category_id") to o.optString("category_name", "Autres"))
            }
        }
    }

    private fun parseLive(raw: String): List<XtreamItem> {
        val a = JSONArray(raw)
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.optString("stream_id")
                add(XtreamItem(id, o.optString("name", "Chaîne"), o.optString("category_id"),
                    o.optString("stream_icon").takeIf { it.isNotBlank() },
                    "${base()}/live/${Uri.encode(username)}/${Uri.encode(password)}/$id.ts"))
            }
        }
    }

    private fun parseVod(raw: String): List<XtreamItem> {
        val a = JSONArray(raw)
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                val id = o.optString("stream_id")
                val ext = o.optString("container_extension", "mp4")
                add(XtreamItem(id, o.optString("name", "Film"), o.optString("category_id"),
                    o.optString("stream_icon").takeIf { it.isNotBlank() },
                    "${base()}/movie/${Uri.encode(username)}/${Uri.encode(password)}/$id.$ext"))
            }
        }
    }

    private fun parseSeries(raw: String): List<XtreamItem> {
        val a = JSONArray(raw)
        return buildList {
            for (i in 0 until a.length()) {
                val o = a.getJSONObject(i)
                add(XtreamItem(o.optString("series_id"), o.optString("name", "Série"),
                    o.optString("category_id"), o.optString("cover").takeIf { it.isNotBlank() }, isSeries = true))
            }
        }
    }

    fun openSeries(scope: kotlinx.coroutines.CoroutineScope, series: XtreamItem) {
        scope.launch {
            loading = true
            try {
                val obj = JSONObject(getJson("${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=get_series_info&series_id=${Uri.encode(series.id)}"))
                val eps = obj.optJSONObject("episodes")
                val out = mutableListOf<XtreamItem>()
                if (eps != null) {
                    val keys = eps.keys()
                    while (keys.hasNext()) {
                        val seasonKey = keys.next()
                        val arr = eps.optJSONArray(seasonKey) ?: continue
                        for (i in 0 until arr.length()) {
                            val e = arr.getJSONObject(i)
                            val id = e.optString("id")
                            val ext = e.optString("container_extension", "mp4")
                            out += XtreamItem(id,
                                "S${e.optString("season", seasonKey)} E${e.optString("episode_num", "?")} — ${e.optString("title", "Épisode")}",
                                streamUrl = "${base()}/series/${Uri.encode(username)}/${Uri.encode(password)}/$id.$ext")
                        }
                    }
                }
                seriesEpisodes = out
                selectedItem = null
                message = "${out.size} épisodes"
            } catch (_: Exception) {
                message = "Impossible de charger les épisodes."
            } finally { loading = false }
        }
    }

    fun toggleFavorite(item: XtreamItem, context: Context) {
        val next = if (item.id in favorites) favorites - item.id else favorites + item.id
        favorites = next
        context.getSharedPreferences("tvmax", Context.MODE_PRIVATE)
            .edit().putStringSet("favorites", next).apply()
    }

    fun restoreFavorites(context: Context) {
        favorites = context.getSharedPreferences("tvmax", Context.MODE_PRIVATE)
            .getStringSet("favorites", emptySet()) ?: emptySet()
    }

    fun loadEpg(scope: kotlinx.coroutines.CoroutineScope, item: XtreamItem) {
        scope.launch {
            try {
                val raw = getJson("${base()}/player_api.php?username=${Uri.encode(username)}&password=${Uri.encode(password)}&action=get_short_epg&stream_id=${Uri.encode(item.id)}&limit=6")
                val root = JSONObject(raw)
                val arr = root.optJSONArray("epg_list") ?: JSONArray()
                epg = buildList {
                    for (i in 0 until arr.length()) {
                        val o = arr.getJSONObject(i)
                        add(EpgItem(o.optString("title"), o.optString("start"), o.optString("end")))
                    }
                }
            } catch (_: Exception) { epg = emptyList() }
        }
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TvMaxTheme { TvMaxApp() } }
    }
}

@Composable
fun TvMaxTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = TextMain, onSurface = TextMain
        ),
        content = content
    )
}

@Composable
fun TvMaxApp(vm: IptvViewModel = viewModel()) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("tvmax", Context.MODE_PRIVATE) }
    var server by remember { mutableStateOf(prefs.getString("server", "") ?: "") }
    var user by remember { mutableStateOf(prefs.getString("user", "") ?: "") }
    var pass by remember { mutableStateOf(prefs.getString("pass", "") ?: "") }
    var search by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Toutes") }
    var showPlayer by remember { mutableStateOf(false) }
    var showEpg by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        vm.restoreFavorites(context)
        vm.server = server
        vm.username = user
        vm.password = pass
        if (server.isNotBlank() && user.isNotBlank() && pass.isNotBlank()) vm.connect(scope)
    }

    if (showPlayer && vm.selectedItem != null) {
        PlayerScreen(vm.selectedItem!!, { showPlayer = false }, {
            showEpg = true
            vm.loadEpg(scope, vm.selectedItem!!)
        }, vm.epg, showEpg) { showEpg = false }
        return
    }

    Row(Modifier.fillMaxSize().background(Bg)) {
        NavigationRail(
            modifier = Modifier.fillMaxHeight().width(120.dp),
            containerColor = Color(0xFF0C0D12)
        ) {
            Spacer(Modifier.height(28.dp))
            Text("TV", color = Accent, fontSize = 25.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(28.dp))
            listOf("Accueil", "Live TV", "Films", "Séries", "Favoris").forEach { tab ->
                NavigationRailItem(
                    selected = vm.section == tab,
                    onClick = {
                        category = "Toutes"
                        search = ""
                        if (tab == "Favoris") vm.section = "Favoris"
                        else if (tab == "Accueil") vm.section = "Accueil"
                        else vm.loadSection(scope, tab)
                    },
                    icon = { Text(if (tab == "Accueil") "⌂" else if (tab == "Favoris") "★" else "•", fontSize = 20.sp) },
                    label = { Text(tab, fontSize = 11.sp) }
                )
            }
        }

        Column(Modifier.fillMaxSize().padding(horizontal = 26.dp, vertical = 20.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("TvMax", fontSize = 30.sp, fontWeight = FontWeight.Bold)
                    Text(
                        when (vm.section) {
                            "Accueil" -> "Bienvenue"
                            "Favoris" -> "Tes favoris"
                            else -> vm.section
                        },
                        color = TextDim
                    )
                }
                if (vm.loading) CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
            }

            Spacer(Modifier.height(16.dp))

            if (!vm.connected) {
                LoginCard(server, { server = it }, user, { user = it }, pass, { pass = it }) {
                    vm.server = server
                    vm.username = user
                    vm.password = pass
                    prefs.edit().putString("server", server).putString("user", user).putString("pass", pass).apply()
                    vm.connect(scope)
                }
            } else if (vm.section == "Accueil") {
                HomeContent(vm, scope, context)
            } else {
                OutlinedTextField(
                    value = search, onValueChange = { search = it },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true,
                    label = { Text("Rechercher") },
                    shape = RoundedCornerShape(14.dp)
                )
                Spacer(Modifier.height(12.dp))

                if (vm.section != "Favoris") {
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        item {
                            FilterChip(selected = category == "Toutes", onClick = { category = "Toutes" }, label = { Text("Toutes") })
                        }
                        items(vm.categories.take(14)) { pair ->
                            FilterChip(selected = category == pair.second, onClick = { category = pair.second }, label = { Text(pair.second) })
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                }

                val visible = if (vm.section == "Favoris") {
                    vm.items.filter { it.id in vm.favorites }
                } else {
                    vm.items.filter {
                        (category == "Toutes" || vm.categories.firstOrNull { c -> c.first == it.categoryId }?.second == category) &&
                        (search.isBlank() || it.name.contains(search, ignoreCase = true))
                    }
                }

                if (vm.section == "Séries" && vm.seriesEpisodes.isNotEmpty()) {
                    LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(vm.seriesEpisodes) { ep ->
                            Card(Modifier.fillMaxWidth().clickable {
                                vm.selectedItem = ep
                                showPlayer = true
                            }) {
                                Text(ep.name, Modifier.padding(18.dp))
                            }
                        }
                    }
                } else {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(190.dp),
                        modifier = Modifier.weight(1f),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        contentPadding = PaddingValues(bottom = 20.dp)
                    ) {
                        items(visible) { item ->
                            MediaCard(item, item.id in vm.favorites, {
                                if (item.isSeries) vm.openSeries(scope, item)
                                else { vm.selectedItem = item; showPlayer = true }
                            }) { vm.toggleFavorite(item, context) }
                        }
                    }
                }
            }

            if (vm.message.isNotBlank()) {
                Spacer(Modifier.height(6.dp))
                Text(vm.message, color = TextDim, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun LoginCard(server: String, onServer: (String) -> Unit, user: String, onUser: (String) -> Unit,
             pass: String, onPass: (String) -> Unit, connect: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = Panel),
        shape = RoundedCornerShape(20.dp)
    ) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Connexion Xtream Codes", fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(server, onServer, Modifier.weight(1f), singleLine = true, label = { Text("Serveur") })
                OutlinedTextField(user, onUser, Modifier.weight(.55f), singleLine = true, label = { Text("Utilisateur") })
                OutlinedTextField(pass, onPass, Modifier.weight(.55f), singleLine = true, label = { Text("Mot de passe") })
                Button(onClick = connect, modifier = Modifier.height(56.dp)) { Text("Connexion") }
            }
        }
    }
}

@Composable
fun HomeContent(vm: IptvViewModel, scope: kotlinx.coroutines.CoroutineScope, context: Context) {
    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Text("Accès rapide", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf("Live TV", "Films", "Séries").forEach { title ->
                Card(
                    Modifier.width(210.dp).height(105.dp).clickable { vm.loadSection(scope, title) },
                    colors = CardDefaults.cardColors(containerColor = Panel)
                ) {
                    Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.Center) {
                        Text(title, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Ouvrir", color = TextDim)
                    }
                }
            }
        }
        if (vm.items.isNotEmpty()) {
            Text("Derniers contenus", fontSize = 20.sp, fontWeight = FontWeight.Bold)
            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                items(vm.items.take(10)) { item ->
                    MediaCard(item, item.id in vm.favorites, {
                        if (item.isSeries) vm.openSeries(scope, item)
                        else vm.selectedItem = item
                    }) { vm.toggleFavorite(item, context) }
                }
            }
        }
    }
}

@Composable
fun MediaCard(item: XtreamItem, favorite: Boolean, open: () -> Unit, toggleFavorite: () -> Unit) {
    Card(
        Modifier.width(190.dp).height(225.dp).clickable { open() },
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Panel)
    ) {
        Box {
            if (!item.icon.isNullOrBlank()) {
                AsyncImage(
                    model = item.icon,
                    contentDescription = null,
                    modifier = Modifier.fillMaxWidth().height(145.dp).clip(RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)),
                    contentScale = ContentScale.Crop
                )
            } else {
                Box(Modifier.fillMaxWidth().height(145.dp).background(Color(0xFF20232C)))
            }
            Text(
                if (favorite) "★" else "☆",
                modifier = Modifier.align(Alignment.TopEnd).padding(10.dp).clickable { toggleFavorite() },
                color = Color.White, fontSize = 24.sp
            )
            Column(Modifier.align(Alignment.BottomStart).padding(12.dp)) {
                Text(item.name, maxLines = 2, fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
fun PlayerScreen(item: XtreamItem, onBack: () -> Unit, onEpg: () -> Unit,
                 epg: List<EpgItem>, showEpg: Boolean, closeEpg: () -> Unit) {
    val context = LocalContext.current
    val player = remember(item.streamUrl) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(item.streamUrl))
            prepare()
            playWhenReady = true
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }

    Box(Modifier.fillMaxSize().background(Color.Black)) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player } },
            modifier = Modifier.fillMaxSize()
        )
        Row(Modifier.align(Alignment.TopStart).padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = onBack) { Text("← Retour") }
            if (item.streamUrl.contains("/live/")) Button(onClick = onEpg) { Text("EPG") }
        }
        if (showEpg) {
            Card(Modifier.align(Alignment.Center).fillMaxWidth(.72f)) {
                Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Programme TV", fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    if (epg.isEmpty()) Text("Aucun programme disponible.")
                    epg.forEach { p ->
                        Text(p.title, fontWeight = FontWeight.SemiBold)
                        Text("${p.start} → ${p.end}", color = TextDim, fontSize = 12.sp)
                    }
                    Button(onClick = closeEpg) { Text("Fermer") }
                }
            }
        }
    }
}
